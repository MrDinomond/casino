from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                           QLabel, QTableWidget, QTableWidgetItem, QHeaderView)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from database import Session, Leaderboard, User
from datetime import datetime, timedelta

class LeaderboardWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)

        # Заголовок
        title = QLabel("🏆 Таблица лидеров")
        title.setAlignment(Qt.AlignCenter)
        title.setFont(QFont('Arial', 24, QFont.Weight.Bold))
        title.setStyleSheet("color: #4CAF50; margin-bottom: 20px;")
        layout.addWidget(title)

        # Таблица
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Место", "Игрок", "Игра", "Счет"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setStyleSheet("""
            QTableWidget {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
            }
            QHeaderView::section {
                background-color: #1d1d1d;
                color: white;
                padding: 5px;
                border: 1px solid #3d3d3d;
            }
            QTableWidget::item {
                padding: 5px;
            }
            QTableWidget::item:selected {
                background-color: #4CAF50;
            }
        """)
        layout.addWidget(self.table)

        # Кнопки фильтрации
        filter_layout = QHBoxLayout()
        
        self.all_button = QPushButton("Все игры")
        self.all_button.clicked.connect(lambda: self.update_leaderboard())
        filter_layout.addWidget(self.all_button)

        self.slots_button = QPushButton("Слоты")
        self.slots_button.clicked.connect(lambda: self.update_leaderboard('slots'))
        filter_layout.addWidget(self.slots_button)

        self.poker_button = QPushButton("Покер")
        self.poker_button.clicked.connect(lambda: self.update_leaderboard('poker'))
        filter_layout.addWidget(self.poker_button)

        self.blackjack_button = QPushButton("Блэкджек")
        self.blackjack_button.clicked.connect(lambda: self.update_leaderboard('blackjack'))
        filter_layout.addWidget(self.blackjack_button)

        layout.addLayout(filter_layout)

        # Стилизация кнопок
        for button in [self.all_button, self.slots_button, self.poker_button, self.blackjack_button]:
            button.setStyleSheet("""
                QPushButton {
                    background-color: #2d2d2d;
                    color: white;
                    border: 2px solid #3d3d3d;
                    border-radius: 5px;
                    padding: 5px;
                }
                QPushButton:hover {
                    background-color: #3d3d3d;
                    border: 2px solid #4d4d4d;
                }
                QPushButton:pressed {
                    background-color: #1d1d1d;
                }
            """)

        self.update_leaderboard()

    def update_leaderboard(self, game_type=None):
        session = Session()
        
        # Получаем данные за последние 7 дней
        week_ago = datetime.now() - timedelta(days=7)
        
        query = session.query(Leaderboard).filter(Leaderboard.updated_at >= week_ago)
        if game_type:
            query = query.filter(Leaderboard.game_type == game_type)
        
        leaders = query.order_by(Leaderboard.score.desc()).limit(10).all()
        
        self.table.setRowCount(len(leaders))
        for i, leader in enumerate(leaders):
            user = session.query(User).get(leader.user_id)
            
            # Место
            place_item = QTableWidgetItem(f"#{i+1}")
            place_item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(i, 0, place_item)
            
            # Игрок
            player_item = QTableWidgetItem(user.username)
            player_item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(i, 1, player_item)
            
            # Игра
            game_item = QTableWidgetItem(leader.game_type)
            game_item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(i, 2, game_item)
            
            # Счет
            score_item = QTableWidgetItem(f"{leader.score:.2f}")
            score_item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(i, 3, score_item)
        
        session.close()

def update_leaderboard_score(user_id, game_type, score):
    session = Session()
    
    # Обновляем или создаем запись в таблице лидеров
    leader = session.query(Leaderboard).filter_by(
        user_id=user_id,
        game_type=game_type
    ).first()
    
    if leader:
        leader.score = max(leader.score, score)
        leader.updated_at = datetime.now()
    else:
        leader = Leaderboard(
            user_id=user_id,
            game_type=game_type,
            score=score,
            updated_at=datetime.now()
        )
        session.add(leader)
    
    session.commit()
    session.close() 