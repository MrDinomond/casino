from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                           QLabel, QProgressBar)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont
from database import Session, DailyBonus, Transaction
from datetime import datetime, timedelta

class BonusSystem:
    def __init__(self):
        self.daily_bonus_amounts = {
            1: 100.0,   # День 1
            2: 200.0,   # День 2
            3: 300.0,   # День 3
            4: 400.0,   # День 4
            5: 500.0,   # День 5
            6: 600.0,   # День 6
            7: 1000.0,  # День 7 (бонус за неделю)
        }

    def check_daily_bonus(self, user):
        session = Session()
        
        # Получаем последний бонус пользователя
        last_bonus = session.query(DailyBonus).filter_by(user_id=user.id).first()
        
        if not last_bonus:
            # Первый бонус
            return self.give_daily_bonus(user, 1, session)
        
        # Проверяем, прошло ли 24 часа с последнего бонуса
        time_since_last = datetime.now() - last_bonus.last_claimed
        
        if time_since_last < timedelta(days=1):
            return None, "Вы уже получили бонус сегодня"
        
        # Проверяем, не пропущен ли день
        if time_since_last > timedelta(days=2):
            # Сброс серии
            return self.give_daily_bonus(user, 1, session)
        
        # Продолжаем серию
        next_streak = last_bonus.streak + 1
        if next_streak > 7:
            next_streak = 1
        
        return self.give_daily_bonus(user, next_streak, session)

    def give_daily_bonus(self, user, streak, session):
        bonus_amount = self.daily_bonus_amounts[streak]
        
        # Создаем запись о бонусе
        bonus = DailyBonus(
            user_id=user.id,
            amount=bonus_amount,
            streak=streak,
            last_claimed=datetime.now()
        )
        
        # Создаем транзакцию
        transaction = Transaction(
            user_id=user.id,
            amount=bonus_amount,
            type='bonus',
            description=f'Ежедневный бонус (день {streak})'
        )
        
        # Обновляем баланс пользователя
        user.balance += bonus_amount
        
        session.add(bonus)
        session.add(transaction)
        session.commit()
        
        return bonus, f"Получен бонус {bonus_amount:.2f} (день {streak})"

class DailyBonusWidget(QWidget):
    def __init__(self, user, parent=None):
        super().__init__(parent)
        self.user = user
        self.bonus_system = BonusSystem()
        self.setup_ui()
        self.update_status()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)

        # Заголовок
        title = QLabel("🎁 Ежедневный бонус")
        title.setAlignment(Qt.AlignCenter)
        title.setFont(QFont('Arial', 24, QFont.Weight.Bold))
        title.setStyleSheet("color: #4CAF50; margin-bottom: 20px;")
        layout.addWidget(title)

        # Прогресс-бар серии
        self.streak_label = QLabel("Серия: 0/7 дней")
        self.streak_label.setAlignment(Qt.AlignCenter)
        self.streak_label.setStyleSheet("color: white; font-size: 16px;")
        layout.addWidget(self.streak_label)

        self.streak_bar = QProgressBar()
        self.streak_bar.setStyleSheet("""
            QProgressBar {
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                text-align: center;
                background-color: #2d2d2d;
            }
            QProgressBar::chunk {
                background-color: #4CAF50;
            }
        """)
        self.streak_bar.setMaximum(7)
        layout.addWidget(self.streak_bar)

        # Следующий бонус
        self.next_bonus_label = QLabel("Следующий бонус: 100.00")
        self.next_bonus_label.setAlignment(Qt.AlignCenter)
        self.next_bonus_label.setStyleSheet("color: white; font-size: 16px;")
        layout.addWidget(self.next_bonus_label)

        # Кнопка получения бонуса
        self.claim_button = QPushButton("🎁 Получить бонус")
        self.claim_button.clicked.connect(self.claim_bonus)
        self.claim_button.setStyleSheet("""
            QPushButton {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 10px;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #3d3d3d;
                border: 2px solid #4d4d4d;
            }
            QPushButton:pressed {
                background-color: #1d1d1d;
            }
            QPushButton:disabled {
                background-color: #1d1d1d;
                border: 2px solid #2d2d2d;
                color: #666666;
            }
        """)
        layout.addWidget(self.claim_button)

        # Таймер обновления
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_status)
        self.timer.start(60000)  # Обновление каждую минуту

    def update_status(self):
        session = Session()
        last_bonus = session.query(DailyBonus).filter_by(user_id=self.user.id).first()
        
        if last_bonus:
            self.streak_label.setText(f"Серия: {last_bonus.streak}/7 дней")
            self.streak_bar.setValue(last_bonus.streak)
            
            next_streak = last_bonus.streak + 1
            if next_streak > 7:
                next_streak = 1
            
            next_bonus = self.bonus_system.daily_bonus_amounts[next_streak]
            self.next_bonus_label.setText(f"Следующий бонус: {next_bonus:.2f}")
            
            # Проверяем, можно ли получить бонус
            time_since_last = datetime.now() - last_bonus.last_claimed
            self.claim_button.setEnabled(time_since_last >= timedelta(days=1))
        else:
            self.streak_label.setText("Серия: 0/7 дней")
            self.streak_bar.setValue(0)
            self.next_bonus_label.setText("Следующий бонус: 100.00")
            self.claim_button.setEnabled(True)
        
        session.close()

    def claim_bonus(self):
        bonus, message = self.bonus_system.check_daily_bonus(self.user)
        if bonus:
            self.update_status()
            # Здесь можно добавить анимацию получения бонуса 