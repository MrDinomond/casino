from PySide6.QtWidgets import QLabel, QWidget
from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QPoint
from PySide6.QtGui import QPainter, QColor, QFont
import random

class ConfettiEffect(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.particles = []
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_particles)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)

    def start(self, duration=2000):
        self.particles = []
        for _ in range(50):
            x = random.randint(0, self.width())
            y = random.randint(0, self.height())
            color = QColor(
                random.randint(0, 255),
                random.randint(0, 255),
                random.randint(0, 255)
            )
            self.particles.append({
                'x': x,
                'y': y,
                'color': color,
                'size': random.randint(5, 15),
                'speed': random.uniform(2, 5),
                'angle': random.uniform(0, 360)
            })
        self.timer.start(16)  # 60 FPS
        QTimer.singleShot(duration, self.stop)

    def stop(self):
        self.timer.stop()
        self.particles = []
        self.update()

    def update_particles(self):
        for particle in self.particles:
            particle['y'] += particle['speed']
            particle['angle'] += 5
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        for particle in self.particles:
            painter.setPen(Qt.NoPen)
            painter.setBrush(particle['color'])
            painter.save()
            painter.translate(particle['x'], particle['y'])
            painter.rotate(particle['angle'])
            painter.drawRect(-particle['size']/2, -particle['size']/2, 
                           particle['size'], particle['size'])
            painter.restore()

class WinLabel(QLabel):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setStyleSheet("""
            QLabel {
                color: #4CAF50;
                font-size: 24px;
                font-weight: bold;
            }
        """)
        self.setAlignment(Qt.AlignCenter)
        self.animation = QPropertyAnimation(self, b"pos")
        self.animation.setDuration(1000)
        self.animation.setEasingCurve(QEasingCurve.OutBounce)

    def show_win(self, amount):
        self.setText(f"🎉 Выигрыш: {amount:.2f}!")
        self.show()
        
        # Анимация появления
        start_pos = self.pos()
        self.move(start_pos.x(), start_pos.y() - 50)
        self.animation.setStartValue(self.pos())
        self.animation.setEndValue(start_pos)
        self.animation.start()

class AchievementPopup(QWidget):
    def __init__(self, achievement, parent=None):
        super().__init__(parent)
        self.setup_ui(achievement)
        self.animation = QPropertyAnimation(self, b"pos")
        self.animation.setDuration(1000)
        self.animation.setEasingCurve(QEasingCurve.OutBounce)

    def setup_ui(self, achievement):
        self.setStyleSheet("""
            QWidget {
                background-color: #2d2d2d;
                border: 2px solid #4CAF50;
                border-radius: 10px;
            }
        """)
        
        layout = QVBoxLayout(self)
        
        title = QLabel("🏆 Достижение разблокировано!")
        title.setStyleSheet("color: #4CAF50; font-size: 18px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        name = QLabel(achievement.name)
        name.setStyleSheet("color: white; font-size: 16px;")
        name.setAlignment(Qt.AlignCenter)
        layout.addWidget(name)
        
        reward = QLabel(f"Награда: {achievement.reward:.2f}")
        reward.setStyleSheet("color: #FFD700; font-size: 14px;")
        reward.setAlignment(Qt.AlignCenter)
        layout.addWidget(reward)

    def show_popup(self):
        self.show()
        start_pos = self.pos()
        self.move(start_pos.x(), start_pos.y() - 100)
        self.animation.setStartValue(self.pos())
        self.animation.setEndValue(start_pos)
        self.animation.start()
        
        # Автоматически скрыть через 3 секунды
        QTimer.singleShot(3000, self.hide) 