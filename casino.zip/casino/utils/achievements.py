from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QScrollArea, QFrame
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from database import Session, Achievement

class AchievementSystem:
    def __init__(self):
        self.achievements = {
            'first_win': {
                'name': 'Первая победа',
                'description': 'Выиграйте свою первую игру',
                'reward': 100
            },
            'high_roller': {
                'name': 'Большая ставка',
                'description': 'Сделайте ставку 1000 или больше',
                'reward': 500
            },
            'lucky_streak': {
                'name': 'Счастливчик',
                'description': 'Выиграйте 5 игр подряд',
                'reward': 1000
            },
            'slots_master': {
                'name': 'Мастер слотов',
                'description': 'Выиграйте джекпот в слотах',
                'reward': 2000
            },
            'poker_pro': {
                'name': 'Покерный профи',
                'description': 'Соберите королевский флеш в покере',
                'reward': 3000
            },
            'blackjack_king': {
                'name': 'Король блэкджека',
                'description': 'Выиграйте 1000 в блэкджеке за одну игру',
                'reward': 2000
            },
            'roulette_wizard': {
                'name': 'Мастер рулетки',
                'description': 'Угадайте число 0 в рулетке',
                'reward': 5000
            },
            'scratch_master': {
                'name': 'Мастер скретч-карт',
                'description': 'Найдите алмаз в скретч-карте',
                'reward': 1000
            },
            'vip_status': {
                'name': 'VIP статус',
                'description': 'Достигните баланса 10000',
                'reward': 5000
            },
            'daily_streak': {
                'name': 'Ежедневный бонус',
                'description': 'Получайте бонусы 7 дней подряд',
                'reward': 1000
            }
        }
        
    def check_achievement(self, user_id, achievement_id):
        session = Session()
        # Проверяем, не получено ли уже достижение
        existing = session.query(Achievement).filter_by(
            user_id=user_id,
            achievement_id=achievement_id
        ).first()
        
        if not existing:
            # Создаем новое достижение
            achievement = Achievement(
                user_id=user_id,
                achievement_id=achievement_id,
                name=self.achievements[achievement_id]['name'],
                description=self.achievements[achievement_id]['description'],
                reward=self.achievements[achievement_id]['reward']
            )
            session.add(achievement)
            
            # Обновляем баланс пользователя
            user = session.query(User).get(user_id)
            user.balance += self.achievements[achievement_id]['reward']
            
            session.commit()
            return True
        return False
        
    def check_game_achievements(self, user_id, game_type, bet_amount, win_amount):
        session = Session()
        
        # Проверяем достижения для конкретной игры
        if game_type == "slots":
            if win_amount >= 1000:
                self.check_achievement(user_id, "slots_master")
        elif game_type == "poker":
            if win_amount >= 1000:
                self.check_achievement(user_id, "poker_pro")
        elif game_type == "blackjack":
            if win_amount >= 1000:
                self.check_achievement(user_id, "blackjack_king")
        elif game_type == "roulette":
            if win_amount >= 5000:
                self.check_achievement(user_id, "roulette_wizard")
        elif game_type == "scratch":
            if win_amount >= 1000:
                self.check_achievement(user_id, "scratch_master")
                
        # Общие достижения
        if win_amount > 0:
            self.check_achievement(user_id, "first_win")
            
        if bet_amount >= 1000:
            self.check_achievement(user_id, "high_roller")
            
        # Проверяем VIP статус
        user = session.query(User).get(user_id)
        if user.balance >= 10000:
            self.check_achievement(user_id, "vip_status")
            
        session.close()

class AchievementsWidget(QWidget):
    def __init__(self, user, parent=None):
        super().__init__(parent)
        self.user = user
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Заголовок
        title = QLabel("🏆 Достижения")
        title.setFont(QFont('Arial', 18, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Область прокрутки для достижений
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #1a1a1a;
            }
        """)
        
        achievements_widget = QWidget()
        achievements_layout = QVBoxLayout(achievements_widget)
        achievements_layout.setSpacing(10)
        
        # Получаем достижения пользователя
        session = Session()
        achievements = session.query(Achievement).filter_by(user_id=self.user.id).all()
        
        for achievement in achievements:
            frame = QFrame()
            frame.setStyleSheet("""
                QFrame {
                    background-color: #2d2d2d;
                    border-radius: 5px;
                    padding: 10px;
                }
            """)
            
            frame_layout = QVBoxLayout(frame)
            
            name_label = QLabel(achievement.name)
            name_label.setFont(QFont('Arial', 14, QFont.Weight.Bold))
            frame_layout.addWidget(name_label)
            
            desc_label = QLabel(achievement.description)
            desc_label.setFont(QFont('Arial', 12))
            frame_layout.addWidget(desc_label)
            
            reward_label = QLabel(f"Награда: {achievement.reward} 💰")
            reward_label.setFont(QFont('Arial', 12))
            frame_layout.addWidget(reward_label)
            
            achievements_layout.addWidget(frame)
            
        session.close()
        
        scroll.setWidget(achievements_widget)
        layout.addWidget(scroll) 