# Пакет с играми казино
from .slots import SlotsGame
from .roulette import RouletteGame
from .blackjack import BlackjackGame
from .poker import PokerGame
from .scratch import ScratchGame

__all__ = ['SlotsGame', 'RouletteGame', 'BlackjackGame', 'PokerGame', 'ScratchGame'] 