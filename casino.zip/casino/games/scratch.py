from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                           QPushButton, QLabel, QSpinBox, QMessageBox, QGridLayout)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from database import Session, User, GameHistory, Transaction
import random

class ScratchGame(QMainWindow):
    def __init__(self, user):
        super().__init__()
        self.session = Session()
        self.user = self.session.merge(user)
        self.session.commit()  # Важно: фиксируем изменения сразу после merge
        
        self.setup_ui()
        self.game_in_progress = False
        self.scratched_cells = set()
        self.symbols = ['💎', '🎰', '💰', '🎲', '🎯', '🎪', '🎨', '🎭', '🎪']
        self.card = []
        self.win_amount = 0
        
        # Показываем окно
        self.show()
        
    def setup_ui(self):
        self.setWindowTitle("🎰 Скретч-карта")
        self.setFixedSize(800, 600)  # Фиксированный размер как у главного окна
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
            }
            QLabel {
                color: white;
                font-size: 16px;
            }
            QPushButton {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 10px;
                font-size: 16px;
                min-width: 80px;
                min-height: 80px;
            }
            QPushButton:hover {
                background-color: #3d3d3d;
            }
            QPushButton:disabled {
                background-color: #1d1d1d;
                color: #666;
            }
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)

        # Информация о балансе
        self.balance_label = QLabel(f"💰 Баланс: {self.user.balance:.2f}")
        self.balance_label.setAlignment(Qt.AlignCenter)
        self.balance_label.setFont(QFont('Arial', 20, QFont.Weight.Bold))
        layout.addWidget(self.balance_label)

        # Сетка для карты
        grid_widget = QWidget()
        self.card_grid = QGridLayout(grid_widget)
        self.card_grid.setSpacing(10)
        
        # Создаем кнопки для карты
        self.cell_buttons = []
        for i in range(3):
            row = []
            for j in range(3):
                btn = QPushButton("?")
                btn.setFont(QFont('Arial', 24))
                btn.clicked.connect(self.create_cell_handler(i, j))
                btn.setEnabled(False)
                self.card_grid.addWidget(btn, i, j)
                row.append(btn)
            self.cell_buttons.append(row)
            
        layout.addWidget(grid_widget)

        # Кнопка покупки карты
        self.buy_button = QPushButton("💰 Купить карту (100)")
        self.buy_button.clicked.connect(self.buy_card)
        layout.addWidget(self.buy_button)

        # Статус игры
        self.status_label = QLabel("Нажмите 'Купить карту' чтобы начать")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setFont(QFont('Arial', 16))
        layout.addWidget(self.status_label)

    def create_cell_handler(self, row, col):
        """Создает обработчик для кнопки ячейки"""
        def handler():
            self.scratch_cell(row, col)
        return handler

    def buy_card(self):
        if self.game_in_progress:
            return

        # Обновляем данные пользователя из базы
        self.session.refresh(self.user)
        
        if self.user.balance < 100:
            self.status_label.setText("Недостаточно средств!")
            return

        self.user.balance -= 100
        
        # Записываем транзакцию ставки
        transaction = Transaction(
            user_id=self.user.id,
            amount=-100,
            type='bet',
            description='Покупка скретч-карты'
        )
        self.session.add(transaction)
        self.session.commit()
        
        # Обновляем отображение баланса
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")
        
        # Генерируем новую карту
        self.card = []
        self.scratched_cells = set()
        self.win_amount = 0
        
        # Добавляем символы на карту
        for i in range(9):
            symbol = random.choice(self.symbols)
            self.card.append(symbol)
            if symbol == '💎':
                self.win_amount += 50
        
        # Включаем все кнопки
        for i in range(3):
            for j in range(3):
                self.cell_buttons[i][j].setText("?")
                self.cell_buttons[i][j].setEnabled(True)
        
        self.game_in_progress = True
        self.buy_button.setEnabled(False)
        self.status_label.setText("Почешите карту!")

    def scratch_cell(self, row, col):
        if not self.game_in_progress:
            return

        index = row * 3 + col
        if index in self.scratched_cells:
            return

        self.scratched_cells.add(index)
        self.cell_buttons[row][col].setText(self.card[index])
        
        # Проверяем, все ли клетки открыты
        if len(self.scratched_cells) == 9:
            self.end_game()

    def end_game(self):
        self.game_in_progress = False
        self.buy_button.setEnabled(True)
        
        # Обновляем данные пользователя из базы
        self.session.refresh(self.user)
        
        if self.win_amount > 0:
            self.user.balance += self.win_amount
            self.status_label.setText(f"🎉 Победа! Выигрыш: {self.win_amount:.2f}")
            
            # Записываем историю игры
            game_history = GameHistory(
                user_id=self.user.id,
                game_type='scratch',
                bet_amount=100,
                win_amount=self.win_amount,
                result='win'
            )
            self.session.add(game_history)
            
            # Записываем транзакцию выигрыша
            transaction = Transaction(
                user_id=self.user.id,
                amount=self.win_amount,
                type='win',
                description='Выигрыш в скретч-карте'
            )
            self.session.add(transaction)
        else:
            self.status_label.setText("😢 Проигрыш!")
            
            # Записываем историю игры
            game_history = GameHistory(
                user_id=self.user.id,
                game_type='scratch',
                bet_amount=100,
                win_amount=0,
                result='lose'
            )
            self.session.add(game_history)

        self.session.commit()
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")

    def closeEvent(self, event):
        if self.session:
            self.session.close()
        super().closeEvent(event) 