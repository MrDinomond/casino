from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                           QPushButton, QLabel, QSpinBox, QMessageBox)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont
from database import Session, User, GameHistory, Transaction, GameProbability
import random

class BlackjackGame(QMainWindow):
    def __init__(self, user):
        super().__init__()
        self.session = Session()
        self.user = self.session.merge(user)
        self.setup_ui()
        self.deck = self.create_deck()
        self.bet = 0
        self.game_in_progress = False
        self.player_hand = []
        self.dealer_hand = []
        self.current_bet = 0
        
    def setup_ui(self):
        self.setWindowTitle("🃏 Блэкджек")
        self.setFixedSize(800, 600)  # Фиксированный размер как у главного окна
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
            }
            QLabel {
                color: white;
                font-size: 16px;
            }
            QPushButton {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 10px;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #3d3d3d;
            }
            QPushButton:disabled {
                background-color: #1d1d1d;
                color: #666;
            }
            QSpinBox {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 5px;
                font-size: 16px;
            }
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)

        # Информация о балансе
        self.balance_label = QLabel(f"💰 Баланс: {self.user.balance:.2f}")
        self.balance_label.setAlignment(Qt.AlignCenter)
        self.balance_label.setFont(QFont('Arial', 20, QFont.Weight.Bold))
        layout.addWidget(self.balance_label)

        # Карты дилера
        self.dealer_label = QLabel("Карты дилера:")
        self.dealer_label.setAlignment(Qt.AlignCenter)
        self.dealer_label.setFont(QFont('Arial', 16))
        layout.addWidget(self.dealer_label)

        self.dealer_cards = QLabel("")
        self.dealer_cards.setAlignment(Qt.AlignCenter)
        self.dealer_cards.setFont(QFont('Arial', 24))
        layout.addWidget(self.dealer_cards)

        # Карты игрока
        self.player_label = QLabel("Ваши карты:")
        self.player_label.setAlignment(Qt.AlignCenter)
        self.player_label.setFont(QFont('Arial', 16))
        layout.addWidget(self.player_label)

        self.player_cards = QLabel("")
        self.player_cards.setAlignment(Qt.AlignCenter)
        self.player_cards.setFont(QFont('Arial', 24))
        layout.addWidget(self.player_cards)

        # Ставка
        bet_layout = QHBoxLayout()
        bet_layout.addWidget(QLabel("Ставка:"))
        self.bet_spinbox = QSpinBox()
        self.bet_spinbox.setRange(1, 1000)
        self.bet_spinbox.setValue(10)
        bet_layout.addWidget(self.bet_spinbox)
        layout.addLayout(bet_layout)

        # Кнопки
        buttons_layout = QHBoxLayout()
        
        self.deal_button = QPushButton("🎲 Раздать")
        self.hit_button = QPushButton("➕ Взять карту")
        self.stand_button = QPushButton("✋ Хватит")
        
        self.deal_button.clicked.connect(self.deal)
        self.hit_button.clicked.connect(self.hit)
        self.stand_button.clicked.connect(self.stand)
        
        self.hit_button.setEnabled(False)
        self.stand_button.setEnabled(False)
        
        buttons_layout.addWidget(self.deal_button)
        buttons_layout.addWidget(self.hit_button)
        buttons_layout.addWidget(self.stand_button)
        layout.addLayout(buttons_layout)

        # Результат
        self.result_label = QLabel("")
        self.result_label.setAlignment(Qt.AlignCenter)
        self.result_label.setFont(QFont('Arial', 16))
        layout.addWidget(self.result_label)

    def create_deck(self):
        suits = ["♠️", "♥️", "♦️", "♣️"]
        values = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
        self.deck = [f"{value}{suit}" for suit in suits for value in values]
        random.shuffle(self.deck)

    def deal(self):
        if self.game_in_progress:
            return

        bet = self.bet_spinbox.value()
        if bet > self.user.balance:
            QMessageBox.warning(self, "Ошибка", "Недостаточно средств!")
            return

        self.user.balance -= bet
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")

        self.create_deck()
        self.player_hand = [self.deck.pop(), self.deck.pop()]
        self.dealer_hand = [self.deck.pop(), self.deck.pop()]

        self.update_display()
        self.game_in_progress = True
        self.deal_button.setEnabled(False)
        self.hit_button.setEnabled(True)
        self.stand_button.setEnabled(True)

    def hit(self):
        if not self.game_in_progress:
            return

        self.player_hand.append(self.deck.pop())
        self.update_display()

        if self.calculate_hand(self.player_hand) > 21:
            self.end_game("Перебор! Вы проиграли!")

    def stand(self):
        if not self.game_in_progress:
            return

        # Дилер берет карты, пока у него меньше 17
        while self.calculate_hand(self.dealer_hand) < 17:
            self.dealer_hand.append(self.deck.pop())

        self.update_display()
        self.determine_winner()

    def calculate_hand(self, hand):
        value = 0
        aces = 0

        for card in hand:
            card_value = card[:-2]  # Убираем эмодзи масти
            if card_value in ["J", "Q", "K"]:
                value += 10
            elif card_value == "A":
                aces += 1
            else:
                value += int(card_value)

        # Добавляем тузы
        for _ in range(aces):
            if value + 11 <= 21:
                value += 11
            else:
                value += 1

        return value

    def update_display(self):
        self.player_cards.setText(" ".join(self.player_hand))
        self.dealer_cards.setText(" ".join(self.dealer_hand))

    def determine_winner(self):
        # Получаем вероятности для пользователя или общие
        probs = self.session.query(GameProbability).filter_by(
            user_id=self.user.id,
            game_type='blackjack'
        ).first()
        
        if not probs:
            # Если нет персональных вероятностей, используем общие
            probs = self.session.query(GameProbability).filter_by(
                user_id=None,
                game_type='blackjack'
            ).first()
        
        # Если вообще нет настроек, используем значения по умолчанию
        win_chance = probs.win_chance if probs else 48.0
        blackjack_chance = probs.royal_chance if probs else 4.8
        
        # Определяем результат на основе вероятностей
        roll = random.random() * 100
        
        dealer_score = self.calculate_hand(self.dealer_hand)
        player_score = self.calculate_hand(self.player_hand)
        
        # Если у игрока блэкджек (21 с двух карт)
        if len(self.player_hand) == 2 and player_score == 21:
            if roll <= blackjack_chance:
                # Игрок выигрывает с блэкджеком
                win_amount = self.current_bet * 2.5  # Выплата 3:2 за блэкджек
                
                # Применяем VIP множитель, если есть
                if self.user.vip_status:
                    win_amount *= self.user.VIP_WIN_MULTIPLIER
                    
                self.user.balance += win_amount
                self.user.total_wins += win_amount
                self.end_game(f"🎉 Блэкджек! Вы выиграли {win_amount:.2f}!")
                
                # Записываем транзакцию выигрыша
                transaction = Transaction(
                    user_id=self.user.id,
                    amount=win_amount,
                    type='win',
                    description='Блэкджек'
                )
                self.session.add(transaction)
                
            else:
                # Дилер тоже получает блэкджек
                self.dealer_hand = ["A♠️", "J♠️"]
                dealer_score = 21
                self.end_game("Ничья! У дилера тоже блэкджек.")
                self.user.balance += self.current_bet  # Возвращаем ставку
                
        # Обычная игра
        elif roll <= win_chance:
            # Игрок выигрывает
            if dealer_score > 21:
                win_amount = self.current_bet * 2
            else:
                # Подбираем счет дилера так, чтобы он был меньше игрока
                while dealer_score >= player_score and dealer_score <= 21:
                    dealer_score -= random.randint(1, 5)
                win_amount = self.current_bet * 2
                
            # Применяем VIP множитель, если есть
            if self.user.vip_status:
                win_amount *= self.user.VIP_WIN_MULTIPLIER
                
            self.user.balance += win_amount
            self.user.total_wins += win_amount
            self.end_game(f"🎉 Вы выиграли {win_amount:.2f}!")
            
            # Записываем транзакцию выигрыша
            transaction = Transaction(
                user_id=self.user.id,
                amount=win_amount,
                type='win',
                description='Выигрыш в блэкджеке'
            )
            self.session.add(transaction)
            
        else:
            # Игрок проигрывает
            if player_score > 21:
                self.end_game("Перебор! Вы проиграли!")
            else:
                # Подбираем счет дилера так, чтобы он был больше игрока, но не более 21
                dealer_score = min(21, player_score + random.randint(1, 4))
                self.end_game(f"Дилер выиграл со счетом {dealer_score}!")
            self.user.total_losses += self.current_bet
            
        # Записываем историю игры
        game_history = GameHistory(
            user_id=self.user.id,
            game_type='blackjack',
            bet_amount=self.current_bet,
            win_amount=win_amount if 'win_amount' in locals() else 0,
            result='win' if 'win_amount' in locals() else 'lose'
        )
        self.session.add(game_history)
        
        # Обновляем баланс и сохраняем изменения
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")
        self.session.commit()
        
        # Сбрасываем состояние игры
        self.game_in_progress = False
        self.current_bet = 0
        self.deal_button.setEnabled(True)
        self.hit_button.setEnabled(False)
        self.stand_button.setEnabled(False)

    def end_game(self, message):
        self.game_in_progress = False
        self.deal_button.setEnabled(True)
        self.hit_button.setEnabled(False)
        self.stand_button.setEnabled(False)
        self.result_label.setText(message)

        # Определяем выигрыш
        bet = self.bet_spinbox.value()
        win_amount = 0

        if "победили" in message:
            win_amount = bet * 2
            self.user.balance += win_amount
            
            # Записываем историю игры
            game_history = GameHistory(
                user_id=self.user.id,
                game_type='blackjack',
                bet_amount=bet,
                win_amount=win_amount,
                result='win'
            )
            self.session.add(game_history)
            
            # Записываем транзакцию
            transaction = Transaction(
                user_id=self.user.id,
                amount=win_amount,
                type='win',
                description=f'Выигрыш в блэкджеке'
            )
            self.session.add(transaction)
        elif "Ничья" in message:
            self.user.balance += bet
            
            # Записываем историю игры
            game_history = GameHistory(
                user_id=self.user.id,
                game_type='blackjack',
                bet_amount=bet,
                win_amount=bet,
                result='draw'
            )
            self.session.add(game_history)
        else:
            # Записываем историю игры
            game_history = GameHistory(
                user_id=self.user.id,
                game_type='blackjack',
                bet_amount=bet,
                win_amount=0,
                result='lose'
            )
            self.session.add(game_history)
            
            # Записываем транзакцию
            transaction = Transaction(
                user_id=self.user.id,
                amount=-bet,
                type='bet',
                description=f'Ставка в блэкджеке'
            )
            self.session.add(transaction)

        self.session.commit()
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")

    def closeEvent(self, event):
        self.session.close()
        super().closeEvent(event) 