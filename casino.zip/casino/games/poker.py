from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                           QPushButton, QLabel, QSpinBox, QMessageBox)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont
from database import Session, User, GameHistory, Transaction, GameProbability
import random

class PokerGame(QMainWindow):
    def __init__(self, user):
        super().__init__()
        self.session = Session()
        self.user = self.session.merge(user)
        self.setup_ui()
        self.create_deck()
        self.game_in_progress = False
        self.deck = []
        self.player_hand = []
        self.computer_hand = []
        self.current_bet = 0
        
    def setup_ui(self):
        self.setWindowTitle("🎰 Покер")
        self.setFixedSize(800, 600)  # Фиксированный размер как у главного окна
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
            }
            QWidget {
                background-color: #1a1a1a;
                color: white;
            }
            QPushButton {
                background-color: #2d2d2d;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
                color: white;
            }
            QPushButton:hover {
                background-color: #3d3d3d;
            }
            QPushButton:disabled {
                background-color: #1d1d1d;
                color: #666;
            }
            QSpinBox {
                background-color: #2d2d2d;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 5px;
                font-size: 14px;
                color: white;
            }
            QLabel {
                color: white;
            }
        """)
        
        # Основной виджет и layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Баланс
        self.balance_label = QLabel(f"💰 Баланс: {self.user.balance:.2f}")
        self.balance_label.setAlignment(Qt.AlignCenter)
        self.balance_label.setFont(QFont('Arial', 20, QFont.Weight.Bold))
        layout.addWidget(self.balance_label)
        
        # Карты компьютера
        self.computer_label = QLabel("Карты компьютера:")
        self.computer_label.setAlignment(Qt.AlignCenter)
        self.computer_label.setFont(QFont('Arial', 16))
        layout.addWidget(self.computer_label)
        
        self.computer_cards = QLabel("")
        self.computer_cards.setAlignment(Qt.AlignCenter)
        self.computer_cards.setFont(QFont('Arial', 24))
        layout.addWidget(self.computer_cards)
        
        # Карты игрока
        self.player_label = QLabel("Ваши карты:")
        self.player_label.setAlignment(Qt.AlignCenter)
        self.player_label.setFont(QFont('Arial', 16))
        layout.addWidget(self.player_label)
        
        self.player_cards = QLabel("")
        self.player_cards.setAlignment(Qt.AlignCenter)
        self.player_cards.setFont(QFont('Arial', 24))
        layout.addWidget(self.player_cards)
        
        # Ставка
        bet_layout = QHBoxLayout()
        bet_layout.addWidget(QLabel("Ставка:"))
        self.bet_input = QSpinBox()
        self.bet_input.setRange(10, 1000)
        self.bet_input.setValue(10)
        self.bet_input.setSingleStep(10)
        bet_layout.addWidget(self.bet_input)
        layout.addLayout(bet_layout)
        
        # Кнопки
        buttons_layout = QHBoxLayout()
        
        self.deal_button = QPushButton("🎲 Раздать")
        self.bet_button = QPushButton("💰 Ставка")
        self.fold_button = QPushButton("❌ Сбросить")
        
        self.deal_button.clicked.connect(self.deal)
        self.bet_button.clicked.connect(self.place_bet)
        self.fold_button.clicked.connect(self.fold)
        
        self.bet_button.setEnabled(False)
        self.fold_button.setEnabled(False)
        
        buttons_layout.addWidget(self.deal_button)
        buttons_layout.addWidget(self.bet_button)
        buttons_layout.addWidget(self.fold_button)
        layout.addLayout(buttons_layout)
        
        # Результат
        self.result_label = QLabel("")
        self.result_label.setAlignment(Qt.AlignCenter)
        self.result_label.setFont(QFont('Arial', 16))
        layout.addWidget(self.result_label)
        
    def create_deck(self):
        suits = ["♠️", "♥️", "♦️", "♣️"]
        values = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
        self.deck = [f"{value}{suit}" for suit in suits for value in values]
        random.shuffle(self.deck)
        
    def deal(self):
        if self.game_in_progress:
            return
            
        bet = self.bet_input.value()
        if bet > self.user.balance:
            QMessageBox.warning(self, "Ошибка", "Недостаточно средств!")
            return
            
        self.user.balance -= bet
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")
        
        # Записываем транзакцию ставки
        transaction = Transaction(
            user_id=self.user.id,
            amount=-bet,
            type='bet',
            description='Ставка в покере'
        )
        self.session.add(transaction)
        self.session.commit()
        
        self.create_deck()
        self.player_hand = [self.deck.pop(), self.deck.pop()]
        self.computer_hand = [self.deck.pop(), self.deck.pop()]
        
        # Показываем карты игрока и скрываем карты компьютера
        self.player_cards.setText(" ".join(self.player_hand))
        self.computer_cards.setText("🂠 🂠")  # Рубашки карт
        
        self.game_in_progress = True
        self.current_bet = bet
        self.deal_button.setEnabled(False)
        self.bet_button.setEnabled(True)
        self.fold_button.setEnabled(True)
        self.result_label.clear()
        
    def place_bet(self):
        if not self.game_in_progress:
            return
            
        bet_amount = self.bet_input.value()
        if bet_amount > self.user.balance:
            QMessageBox.warning(self, "Ошибка", "Недостаточно средств!")
            return
            
        self.current_bet += bet_amount
        self.user.balance -= bet_amount
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")
        
        # Записываем транзакцию ставки
        transaction = Transaction(
            user_id=self.user.id,
            amount=-bet_amount,
            type='bet',
            description='Дополнительная ставка в покере'
        )
        self.session.add(transaction)
        self.session.commit()
        
        self.determine_winner()
        
    def fold(self):
        if not self.game_in_progress:
            return
            
        self.end_game("Вы сбросили карты")
        
    def determine_winner(self):
        # Получаем вероятности для пользователя или общие
        probs = self.session.query(GameProbability).filter_by(
            user_id=self.user.id,
            game_type='poker'
        ).first()
        
        if not probs:
            # Если нет персональных вероятностей, используем общие
            probs = self.session.query(GameProbability).filter_by(
                user_id=None,
                game_type='poker'
            ).first()
        
        # Если вообще нет настроек, используем значения по умолчанию
        win_chance = probs.win_chance if probs else 50.0
        royal_chance = probs.royal_chance if probs else 0.1
        
        # Определяем результат на основе вероятностей
        roll = random.random() * 100
        
        if roll <= royal_chance:
            # Роял-флеш для игрока
            self.player_hand = ["A♠️", "K♠️", "Q♠️", "J♠️", "10♠️"]
            # Даем компьютеру хорошую, но не выигрышную комбинацию
            self.computer_hand = ["A♥️", "K♥️", "Q♥️", "J♥️", "9♥️"]
        elif roll <= win_chance:
            # Обычный выигрыш - даем игроку комбинацию лучше, чем у компьютера
            player_combinations = [
                ["A♠️", "A♥️", "A♦️", "K♠️", "K♥️"],  # Фулл-хаус
                ["A♠️", "A♥️", "A♦️", "A♣️", "K♠️"],  # Каре
                ["10♠️", "J♠️", "Q♠️", "K♠️", "A♠️"],  # Стрит-флеш
            ]
            computer_combinations = [
                ["K♠️", "K♥️", "K♦️", "Q♠️", "Q♥️"],  # Меньший фулл-хаус
                ["K♠️", "K♥️", "K♦️", "K♣️", "Q♠️"],  # Меньшее каре
                ["9♠️", "10♠️", "J♠️", "Q♠️", "K♠️"],  # Меньший стрит-флеш
            ]
            combination_index = random.randint(0, len(player_combinations) - 1)
            self.player_hand = player_combinations[combination_index]
            self.computer_hand = computer_combinations[combination_index]
        else:
            # Проигрыш - даем компьютеру комбинацию лучше
            player_combinations = [
                ["K♠️", "K♥️", "K♦️", "Q♠️", "J♥️"],  # Тройка
                ["A♠️", "K♠️", "Q♠️", "J♥️", "10♦️"],  # Старшая карта
                ["A♠️", "A♥️", "K♦️", "Q♠️", "J♥️"],  # Пара
            ]
            computer_combinations = [
                ["A♠️", "A♥️", "A♦️", "K♠️", "K♥️"],  # Фулл-хаус
                ["10♠️", "J♠️", "Q♠️", "K♠️", "A♠️"],  # Стрит-флеш
                ["A♠️", "A♥️", "A♦️", "A♣️", "K♠️"],  # Каре
            ]
            combination_index = random.randint(0, len(player_combinations) - 1)
            self.player_hand = player_combinations[combination_index]
            self.computer_hand = computer_combinations[combination_index]
        
        # Показываем карты
        self.computer_cards.setText(" ".join(self.computer_hand))
        self.player_cards.setText(" ".join(self.player_hand))
        
        # Определяем победителя
        player_score = self.calculate_hand(self.player_hand)
        computer_score = self.calculate_hand(self.computer_hand)
        
        win_amount = 0
        if player_score > computer_score:
            win_amount = self.current_bet * 2
            if player_score >= 900:  # Роял-флеш
                win_amount = self.current_bet * 100
            elif player_score >= 800:  # Стрит-флеш
                win_amount = self.current_bet * 50
            elif player_score >= 700:  # Каре
                win_amount = self.current_bet * 25
            elif player_score >= 600:  # Фулл-хаус
                win_amount = self.current_bet * 10
            elif player_score >= 500:  # Флеш
                win_amount = self.current_bet * 5
            
            # Применяем VIP множитель, если есть
            if self.user.vip_status:
                win_amount *= self.user.VIP_WIN_MULTIPLIER
            
            self.user.balance += win_amount
            self.user.total_wins += win_amount
            self.result_label.setText(f"🎉 Вы выиграли {win_amount:.2f}!")
            
            # Записываем транзакцию выигрыша
            transaction = Transaction(
                user_id=self.user.id,
                amount=win_amount,
                type='win',
                description='Выигрыш в покере'
            )
            self.session.add(transaction)
        else:
            self.user.total_losses += self.current_bet
            self.result_label.setText("😢 Вы проиграли!")
            
        # Записываем историю игры
        game_history = GameHistory(
            user_id=self.user.id,
            game_type='poker',
            bet_amount=self.current_bet,
            win_amount=win_amount,
            result='win' if win_amount > 0 else 'lose'
        )
        self.session.add(game_history)
        
        # Обновляем баланс и сохраняем изменения
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")
        self.session.commit()
        
        # Сбрасываем состояние игры
        self.game_in_progress = False
        self.current_bet = 0
        self.deal_button.setEnabled(True)
        self.bet_button.setEnabled(False)
        self.fold_button.setEnabled(False)
        
    def calculate_hand(self, hand):
        values = [card[:-2] for card in hand]  # Убираем эмодзи масти
        suits = [card[-2:] for card in hand]
        
        # Флеш (одинаковые масти)
        if len(set(suits)) == 1:
            return 100 + sum(self.card_value(value) for value in values)
            
        # Пара
        if len(set(values)) == 1:
            return 50 + self.card_value(values[0])
            
        # Старшая карта
        return max(self.card_value(value) for value in values)
        
    def card_value(self, value):
        if value == "A":
            return 14
        elif value == "K":
            return 13
        elif value == "Q":
            return 12
        elif value == "J":
            return 11
        return int(value)
        
    def end_game(self, message):
        self.game_in_progress = False
        self.deal_button.setEnabled(True)
        self.bet_button.setEnabled(False)
        self.fold_button.setEnabled(False)
        self.result_label.setText(message)
        
    def closeEvent(self, event):
        self.session.close()
        super().closeEvent(event) 