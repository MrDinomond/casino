from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                           QPushButton, QLabel, QSpinBox, QGridLayout)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont
from database import Session, User, GameHistory, Transaction, GameProbability
import random

class RouletteGame(QMainWindow):
    def __init__(self, user):
        super().__init__()
        self.session = Session()
        self.user = self.session.merge(user)
        self.setup_ui()
        self.game_in_progress = False
        self.selected_numbers = []
        self.selected_colors = []
        self.bet_amount = 0

    def setup_ui(self):
        self.setWindowTitle("🎰 Рулетка")
        self.setFixedSize(800, 600)  # Фиксированный размер как у главного окна
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
            }
            QLabel {
                color: white;
                font-size: 16px;
            }
            QPushButton {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 10px;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #3d3d3d;
            }
            QPushButton:disabled {
                background-color: #1d1d1d;
                color: #666;
            }
            QSpinBox {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 5px;
                font-size: 16px;
            }
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)

        # Информация о балансе
        self.balance_label = QLabel(f"💰 Баланс: {self.user.balance:.2f}")
        self.balance_label.setAlignment(Qt.AlignCenter)
        self.balance_label.setFont(QFont('Arial', 20, QFont.Weight.Bold))
        layout.addWidget(self.balance_label)

        # Статус игры
        self.status_label = QLabel("Выберите число или цвет")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setFont(QFont('Arial', 16))
        layout.addWidget(self.status_label)

        # Сетка для чисел
        self.numbers_grid = QGridLayout()
        self.numbers_grid.setSpacing(5)
        
        # Создаем кнопки для чисел
        self.number_buttons = []
        for i in range(37):  # 0-36
            btn = QPushButton(str(i))
            btn.setFixedSize(60, 60)
            btn.setFont(QFont('Arial', 20))
            
            # Устанавливаем цвет кнопки
            if i == 0:
                btn.setStyleSheet("background-color: #008000;")  # Зеленый для 0
            elif i in [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]:
                btn.setStyleSheet("background-color: #FF0000;")  # Красный
            else:
                btn.setStyleSheet("background-color: #000000;")  # Черный
                
            # Исправляем lambda-функцию
            btn.clicked.connect(self.create_number_handler(i))
            self.numbers_grid.addWidget(btn, i // 12, i % 12)
            self.number_buttons.append(btn)

        layout.addLayout(self.numbers_grid)

        # Кнопки для цветов
        colors_layout = QHBoxLayout()
        
        self.red_button = QPushButton("🔴 Красное")
        self.red_button.setStyleSheet("background-color: #FF0000;")
        self.red_button.clicked.connect(self.create_color_handler('red'))
        
        self.black_button = QPushButton("⚫ Черное")
        self.black_button.setStyleSheet("background-color: #000000;")
        self.black_button.clicked.connect(self.create_color_handler('black'))
        
        colors_layout.addWidget(self.red_button)
        colors_layout.addWidget(self.black_button)
        layout.addLayout(colors_layout)

        # Ставка
        bet_layout = QHBoxLayout()
        self.bet_spinbox = QSpinBox()
        self.bet_spinbox.setRange(10, 1000)
        self.bet_spinbox.setValue(100)
        self.bet_spinbox.setSingleStep(10)
        bet_layout.addWidget(QLabel("Ставка:"))
        bet_layout.addWidget(self.bet_spinbox)
        layout.addLayout(bet_layout)

        # Кнопка вращения
        self.spin_button = QPushButton("🎰 Крутить")
        self.spin_button.clicked.connect(self.spin)
        layout.addWidget(self.spin_button)

    def create_number_handler(self, number):
        """Создает обработчик для кнопки числа"""
        def handler():
            self.select_number(number)
        return handler

    def create_color_handler(self, color):
        """Создает обработчик для кнопки цвета"""
        def handler():
            self.select_color(color)
        return handler

    def select_number(self, number):
        if self.game_in_progress:
            return
            
        self.selected_numbers.append(number)
        self.selected_colors = []
        
        # Сбрасываем стили всех кнопок
        for btn in self.number_buttons:
            if int(btn.text()) == 0:
                btn.setStyleSheet("background-color: #008000;")
            elif int(btn.text()) in [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]:
                btn.setStyleSheet("background-color: #FF0000;")
            else:
                btn.setStyleSheet("background-color: #000000;")
                
        # Подсвечиваем выбранное число
        self.number_buttons[number].setStyleSheet("background-color: #FFFF00;")
        
        # Отключаем кнопки цветов
        self.red_button.setEnabled(False)
        self.black_button.setEnabled(False)
        
        self.status_label.setText(f"Выбрано число: {number}")

    def select_color(self, color):
        if self.game_in_progress:
            return
            
        self.selected_colors.append(color)
        self.selected_numbers = []
        
        # Сбрасываем стили всех кнопок
        for btn in self.number_buttons:
            if int(btn.text()) == 0:
                btn.setStyleSheet("background-color: #008000;")
            elif int(btn.text()) in [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]:
                btn.setStyleSheet("background-color: #FF0000;")
            else:
                btn.setStyleSheet("background-color: #000000;")
                
        # Отключаем кнопки чисел
        for btn in self.number_buttons:
            btn.setEnabled(False)
            
        self.status_label.setText(f"Выбран цвет: {'красный' if color == 'red' else 'черный'}")

    def spin(self):
        if self.game_in_progress or (not self.selected_numbers and not self.selected_colors):
            return
            
        self.bet_amount = self.bet_spinbox.value()
        if self.user.balance < self.bet_amount:
            self.status_label.setText("Недостаточно средств!")
            return
            
        self.user.balance -= self.bet_amount
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")
        
        # Записываем транзакцию ставки
        transaction = Transaction(
            user_id=self.user.id,
            amount=-self.bet_amount,
            type='bet',
            description='Ставка в рулетке'
        )
        self.session.add(transaction)
        self.session.commit()
        
        # Получаем вероятности для пользователя или общие
        probs = self.session.query(GameProbability).filter_by(
            user_id=self.user.id,
            game_type='roulette'
        ).first()
        
        if not probs:
            # Если нет персональных вероятностей, используем общие
            probs = self.session.query(GameProbability).filter_by(
                user_id=None,
                game_type='roulette'
            ).first()
        
        # Если вообще нет настроек, используем значения по умолчанию
        red_chance = probs.red_chance if probs else 48.6
        black_chance = probs.black_chance if probs else 48.6
        zero_chance = probs.zero_chance if probs else 2.8
        
        # Определяем результат на основе вероятностей
        roll = random.random() * 100
        
        if roll <= zero_chance:
            # Выпал зеро
            winning_number = 0
        elif roll <= zero_chance + red_chance:
            # Выпало красное число
            winning_number = random.choice([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36])
        else:
            # Выпало черное число
            winning_number = random.choice([2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35])
        
        # Определяем цвет выпавшего числа
        if winning_number == 0:
            winning_color = 'green'
        elif winning_number in [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]:
            winning_color = 'red'
        else:
            winning_color = 'black'
            
        # Подсвечиваем выигрышное число
        for btn in self.number_buttons:
            if int(btn.text()) == winning_number:
                btn.setStyleSheet("background-color: #FFFF00;")
                
        win_amount = 0
        
        # Проверяем выигрыш
        if self.selected_numbers and winning_number in self.selected_numbers:
            win_amount = self.bet_amount * 35  # Выигрыш 35 к 1 при ставке на число
            self.status_label.setText(f"🎉 Выпало число {winning_number}! Вы выиграли!")
        elif self.selected_colors:
            selected_color = self.selected_colors[0]
            if (selected_color == 'red' and winning_color == 'red') or \
               (selected_color == 'black' and winning_color == 'black'):
                win_amount = self.bet_amount * 2  # Выигрыш 2 к 1 при ставке на цвет
                self.status_label.setText(f"🎉 Выпал {winning_color}! Вы выиграли!")
            else:
                self.status_label.setText(f"Выпал {winning_color}. Вы проиграли.")
        else:
            self.status_label.setText(f"Выпало число {winning_number} ({winning_color})")
            
        if win_amount > 0:
            # Применяем VIP множитель, если есть
            if self.user.vip_status:
                win_amount *= self.user.VIP_WIN_MULTIPLIER
                
            self.user.balance += win_amount
            self.user.total_wins += win_amount
            
            # Записываем транзакцию выигрыша
            transaction = Transaction(
                user_id=self.user.id,
                amount=win_amount,
                type='win',
                description='Выигрыш в рулетке'
            )
            self.session.add(transaction)
        else:
            self.user.total_losses += self.bet_amount
            
        # Записываем историю игры
        game_history = GameHistory(
            user_id=self.user.id,
            game_type='roulette',
            bet_amount=self.bet_amount,
            win_amount=win_amount,
            result='win' if win_amount > 0 else 'lose'
        )
        self.session.add(game_history)
        
        # Обновляем баланс и сохраняем изменения
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")
        self.session.commit()
        
        # Сбрасываем выбор
        self.selected_numbers = []
        self.selected_colors = []
        
        # Включаем все кнопки
        for btn in self.number_buttons:
            btn.setEnabled(True)
        self.red_button.setEnabled(True)
        self.black_button.setEnabled(True)

    def closeEvent(self, event):
        self.session.close()
        super().closeEvent(event) 