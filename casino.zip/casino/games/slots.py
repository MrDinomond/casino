from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                           QPushButton, QLabel, QSpinBox, QMessageBox)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont
from database import Session, User, GameHistory, Transaction, GameProbability
import random

class SlotsGame(QMainWindow):
    def __init__(self, user):
        super().__init__()
        self.session = Session()
        self.user = self.session.merge(user)
        self.setup_ui()
        self.spinning = False
        self.current_bet = 0
        
    def setup_ui(self):
        self.setWindowTitle("🎰 Слоты")
        self.setFixedSize(800, 600)  # Фиксированный размер как у главного окна
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
            }
            QWidget {
                background-color: #1a1a1a;
                color: white;
            }
            QPushButton {
                background-color: #2d2d2d;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
                color: white;
            }
            QPushButton:hover {
                background-color: #3d3d3d;
            }
            QPushButton:disabled {
                background-color: #1d1d1d;
                color: #666;
            }
            QSpinBox {
                background-color: #2d2d2d;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 5px;
                font-size: 14px;
                color: white;
            }
            QLabel {
                color: white;
            }
        """)
        
        # Основной виджет и layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Баланс
        self.balance_label = QLabel(f"💰 Баланс: {self.user.balance:.2f}")
        self.balance_label.setAlignment(Qt.AlignCenter)
        self.balance_label.setFont(QFont('Arial', 18))
        layout.addWidget(self.balance_label)
        
        # Барабаны
        reels_layout = QHBoxLayout()
        self.reel_labels = []
        self.symbols = ["🍒", "🍋", "🍊", "🍇", "💎", "💰", "💸"]
        
        for i in range(3):
            reel = QLabel(random.choice(self.symbols))
            reel.setFont(QFont('Arial', 48))
            reel.setAlignment(Qt.AlignCenter)
            reel.setStyleSheet("""
                background-color: #2d2d2d;
                border: 2px solid #3d3d3d;
                border-radius: 10px;
                padding: 20px;
                min-width: 100px;
                min-height: 100px;
            """)
            self.reel_labels.append(reel)
            reels_layout.addWidget(reel)
        
        layout.addLayout(reels_layout)
        
        # Ставка
        bet_layout = QHBoxLayout()
        bet_layout.addWidget(QLabel("Ставка:"))
        self.bet_input = QSpinBox()
        self.bet_input.setRange(10, 1000)
        self.bet_input.setValue(10)
        self.bet_input.setSingleStep(10)
        bet_layout.addWidget(self.bet_input)
        layout.addLayout(bet_layout)
        
        # Кнопка спина
        self.spin_button = QPushButton("🎰 Крутить")
        self.spin_button.clicked.connect(self.spin)
        layout.addWidget(self.spin_button)
        
        # Результат
        self.result_label = QLabel("")
        self.result_label.setAlignment(Qt.AlignCenter)
        self.result_label.setFont(QFont('Arial', 16))
        layout.addWidget(self.result_label)
        
        # Таймер для анимации
        self.spin_timer = QTimer()
        self.spin_timer.timeout.connect(self.update_reels)
        self.spin_count = 0
        
    def spin(self):
        if self.spinning:
            return
            
        bet = self.bet_input.value()
        if bet > self.user.balance:
            QMessageBox.warning(self, "Ошибка", "Недостаточно средств!")
            return
        
        self.user.balance -= bet
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")
        
        # Записываем транзакцию ставки
        transaction = Transaction(
            user_id=self.user.id,
            amount=-bet,
            type='bet',
            description='Ставка в слотах'
        )
        self.session.add(transaction)
        self.session.commit()
        
        # Начинаем анимацию
        self.spinning = True
        self.spin_count = 0
        self.spin_button.setEnabled(False)
        self.current_bet = bet
        self.result_label.clear()
        self.spin_timer.start(100)
        
    def update_reels(self):
        if not self.spinning:
            return
            
        # Обновляем символы на барабанах
        for reel in self.reel_labels:
            reel.setText(random.choice(self.symbols))
        
        self.spin_count += 1
        if self.spin_count >= 20:  # 20 обновлений для анимации
            self.spinning = False
            self.spin_timer.stop()
            self.spin_button.setEnabled(True)
            self.check_win()
                
    def check_win(self):
        # Получаем вероятности для пользователя или общие
        probs = self.session.query(GameProbability).filter_by(
            user_id=self.user.id,
            game_type='slots'
        ).first()
        
        if not probs:
            # Если нет персональных вероятностей, используем общие
            probs = self.session.query(GameProbability).filter_by(
                user_id=None,
                game_type='slots'
            ).first()
        
        # Если вообще нет настроек, используем значения по умолчанию
        win_chance = probs.win_chance if probs else 50.0
        jackpot_chance = probs.jackpot_chance if probs else 1.0
        
        # Определяем, будет ли выигрыш
        if random.random() * 100 <= win_chance:
            # Определяем тип выигрыша
            if random.random() * 100 <= jackpot_chance:
                # Джекпот - все символы 💎
                symbols = ["💎", "💎", "💎"]
            else:
                # Обычный выигрыш - случайный символ три раза
                symbol = random.choice(self.symbols)
                symbols = [symbol, symbol, symbol]
        else:
            # Проигрыш - разные символы
            symbols = random.sample(self.symbols, 3)
        
        # Устанавливаем символы на барабаны
        for i, symbol in enumerate(symbols):
            self.reel_labels[i].setText(symbol)
        
        win_amount = 0
        symbols_shown = [label.text() for label in self.reel_labels]
        
        # Проверяем выигрышные комбинации
        if len(set(symbols_shown)) == 1:  # Все символы одинаковые
            symbol = symbols_shown[0]
            if symbol == "💎":  # Джекпот
                win_amount = self.current_bet * 100
                self.result_label.setText(f"🎉 ДЖЕКПОТ! Вы выиграли {win_amount:.2f}!")
            elif symbol == "💰":  # Крупный выигрыш
                win_amount = self.current_bet * 50
                self.result_label.setText(f"🎉 Крупный выигрыш! Вы выиграли {win_amount:.2f}!")
            elif symbol == "💸":  # Средний выигрыш
                win_amount = self.current_bet * 25
                self.result_label.setText(f"🎉 Средний выигрыш! Вы выиграли {win_amount:.2f}!")
            elif symbol in ["🍇", "🍊"]:  # Небольшой выигрыш
                win_amount = self.current_bet * 10
                self.result_label.setText(f"🎉 Выигрыш! Вы выиграли {win_amount:.2f}!")
            else:  # Минимальный выигрыш
                win_amount = self.current_bet * 5
                self.result_label.setText(f"🎉 Маленький выигрыш! Вы выиграли {win_amount:.2f}!")
                
            # Применяем VIP множитель, если есть
            if self.user.vip_status:
                win_amount *= self.user.VIP_WIN_MULTIPLIER
                
            self.user.balance += win_amount
            self.user.total_wins += win_amount
            
            # Записываем транзакцию выигрыша
            transaction = Transaction(
                user_id=self.user.id,
                amount=win_amount,
                type='win',
                description='Выигрыш в слотах'
            )
            self.session.add(transaction)
        else:
            self.result_label.setText("😢 Вы проиграли!")
            self.user.total_losses += self.current_bet
            
        # Записываем историю игры
        game_history = GameHistory(
            user_id=self.user.id,
            game_type='slots',
            bet_amount=self.current_bet,
            win_amount=win_amount,
            result='win' if win_amount > 0 else 'lose'
        )
        self.session.add(game_history)
        
        # Обновляем баланс и сохраняем изменения
        self.balance_label.setText(f"💰 Баланс: {self.user.balance:.2f}")
        self.session.commit()
        
    def closeEvent(self, event):
        self.session.close()
        super().closeEvent(event) 