from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QComboBox, QSpinBox, QPushButton, QMessageBox)
from PySide6.QtCore import Qt
from database import Session, GameProbability, User

class ProbabilityManager(QWidget):
    def __init__(self):
        super().__init__()
        self.session = Session()
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout()
        
        # Заголовок
        title = QLabel("🎲 Управление вероятностями")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #FFD700;")
        layout.addWidget(title)
        
        # Выбор игры и пользователя
        controls_layout = QHBoxLayout()
        
        self.game_combo = QComboBox()
        self.game_combo.addItems(["slots", "poker", "blackjack", "roulette", "scratch"])
        self.game_combo.currentTextChanged.connect(self.update_probabilities)
        controls_layout.addWidget(QLabel("Игра:"))
        controls_layout.addWidget(self.game_combo)
        
        self.user_combo = QComboBox()
        self.user_combo.addItem("Все пользователи", None)
        self.load_users()
        self.user_combo.currentIndexChanged.connect(self.update_probabilities)
        controls_layout.addWidget(QLabel("Пользователь:"))
        controls_layout.addWidget(self.user_combo)
        
        layout.addLayout(controls_layout)
        
        # Общие вероятности
        general_group = QVBoxLayout()
        general_group.addWidget(QLabel("Общие вероятности"))
        self.win_chance = self.create_probability_input("Шанс выигрыша (%)")
        general_group.addLayout(self.win_chance)
        layout.addLayout(general_group)
        
        # Специфичные вероятности для разных игр
        self.game_specific_layout = QVBoxLayout()
        layout.addLayout(self.game_specific_layout)
        
        # Кнопка сохранения
        save_btn = QPushButton("💾 Сохранить")
        save_btn.clicked.connect(self.save_probabilities)
        save_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        layout.addWidget(save_btn)
        
        self.setLayout(layout)
        self.update_probabilities()
        
    def create_probability_input(self, label_text, value=50):
        layout = QHBoxLayout()
        layout.addWidget(QLabel(label_text))
        spinbox = QSpinBox()
        spinbox.setRange(0, 100)
        spinbox.setValue(value)
        spinbox.setSuffix("%")
        layout.addWidget(spinbox)
        return layout
        
    def load_users(self):
        users = self.session.query(User).all()
        for user in users:
            self.user_combo.addItem(f"{user.username} (ID: {user.id})", user.id)
            
    def update_probabilities(self):
        # Очищаем специфичные вероятности
        while self.game_specific_layout.count():
            item = self.game_specific_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
                
        game_type = self.game_combo.currentText()
        user_id = self.user_combo.currentData()
        
        # Загружаем текущие вероятности
        prob = self.session.query(GameProbability).filter_by(
            game_type=game_type,
            user_id=user_id
        ).first()
        
        if not prob:
            prob = GameProbability(game_type=game_type, user_id=user_id)
            
        # Обновляем общие вероятности
        self.win_chance.itemAt(1).widget().setValue(int(prob.win_chance))
        
        # Добавляем специфичные вероятности в зависимости от игры
        if game_type == "slots":
            self.game_specific_layout.addLayout(
                self.create_probability_input("Шанс джекпота (%)", prob.jackpot_chance)
            )
        elif game_type == "poker":
            self.game_specific_layout.addLayout(
                self.create_probability_input("Шанс роял флеша (%)", prob.royal_chance)
            )
        elif game_type == "blackjack":
            self.game_specific_layout.addLayout(
                self.create_probability_input("Шанс блэкджека (%)", prob.blackjack_chance)
            )
        elif game_type == "roulette":
            self.game_specific_layout.addLayout(
                self.create_probability_input("Шанс красного (%)", prob.red_chance)
            )
            self.game_specific_layout.addLayout(
                self.create_probability_input("Шанс черного (%)", prob.black_chance)
            )
            self.game_specific_layout.addLayout(
                self.create_probability_input("Шанс нуля (%)", prob.zero_chance)
            )
        elif game_type == "scratch":
            self.game_specific_layout.addLayout(
                self.create_probability_input("Шанс алмаза (%)", prob.diamond_chance)
            )
            
    def save_probabilities(self):
        game_type = self.game_combo.currentText()
        user_id = self.user_combo.currentData()
        
        prob = self.session.query(GameProbability).filter_by(
            game_type=game_type,
            user_id=user_id
        ).first()
        
        if not prob:
            prob = GameProbability(game_type=game_type, user_id=user_id)
            self.session.add(prob)
            
        # Сохраняем общие вероятности
        prob.win_chance = self.win_chance.itemAt(1).widget().value()
        
        # Сохраняем специфичные вероятности
        if game_type == "slots":
            prob.jackpot_chance = self.game_specific_layout.itemAt(0).layout().itemAt(1).widget().value()
        elif game_type == "poker":
            prob.royal_chance = self.game_specific_layout.itemAt(0).layout().itemAt(1).widget().value()
        elif game_type == "blackjack":
            prob.blackjack_chance = self.game_specific_layout.itemAt(0).layout().itemAt(1).widget().value()
        elif game_type == "roulette":
            prob.red_chance = self.game_specific_layout.itemAt(0).layout().itemAt(1).widget().value()
            prob.black_chance = self.game_specific_layout.itemAt(1).layout().itemAt(1).widget().value()
            prob.zero_chance = self.game_specific_layout.itemAt(2).layout().itemAt(1).widget().value()
        elif game_type == "scratch":
            prob.diamond_chance = self.game_specific_layout.itemAt(0).layout().itemAt(1).widget().value()
            
        self.session.commit()
        QMessageBox.information(self, "Успех", "Вероятности успешно сохранены!")
        
    def closeEvent(self, event):
        self.session.close()
        super().closeEvent(event) 