# Инициализация пакета admin
from .admin import AdminPanel

__all__ = ['AdminPanel'] 