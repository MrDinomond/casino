from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                           QPushButton, QLabel, QTableWidget, QTableWidgetItem,
                           QMessageBox, QTabWidget, QHeaderView, QInputDialog, QDateEdit,
                           QSpinBox, QComboBox, QDoubleSpinBox)
from PySide6.QtCore import Qt, QDate
from PySide6.QtGui import QFont
from database import Session, User, GameHistory, Transaction, DepositRequest, GameProbability, ShopItem
from datetime import datetime, timedelta
from .probability_manager import ProbabilityManager

class AdminPanel(QMainWindow):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.session = Session()
        self.setup_ui()
        self.refresh_data()

    def setup_ui(self):
        self.setWindowTitle("👑 Админ-панель")
        self.setMinimumSize(1000, 800)
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
            }
            QWidget {
                background-color: #1a1a1a;
                color: white;
            }
            QPushButton {
                background-color: #2d2d2d;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 10px;
                font-size: 14px;
                color: white;
                min-width: 150px;
            }
            QPushButton:hover {
                background-color: #3d3d3d;
            }
            QPushButton:pressed {
                background-color: #4d4d4d;
            }
            QTableWidget {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                gridline-color: #3d3d3d;
            }
            QHeaderView::section {
                background-color: #1d1d1d;
                color: white;
                padding: 5px;
                border: 1px solid #3d3d3d;
            }
            QTabWidget::pane {
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                background-color: #1a1a1a;
            }
            QTabBar::tab {
                background-color: #2d2d2d;
                color: white;
                padding: 10px;
                margin: 2px;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                min-width: 100px;
            }
            QTabBar::tab:selected {
                background-color: #4CAF50;
                border: 2px solid #45a049;
            }
            QTabBar::tab:hover:!selected {
                background-color: #3d3d3d;
            }
            QComboBox, QSpinBox, QDoubleSpinBox {
                background-color: #2d2d2d;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 5px;
                color: white;
                min-width: 150px;
            }
        """)
        
        # Основной виджет и layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)

        # Заголовок
        title = QLabel("👑 Админ-панель казино")
        title.setAlignment(Qt.AlignCenter)
        title.setFont(QFont('Arial', 24, QFont.Weight.Bold))
        title.setStyleSheet("color: #4CAF50; margin-bottom: 20px;")
        layout.addWidget(title)

        # Создаем вкладки
        tabs = QTabWidget()
        tabs.setStyleSheet("""
            QTabWidget::pane {
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                background-color: #1a1a1a;
            }
            QTabBar::tab {
                background-color: #2d2d2d;
                color: white;
                padding: 10px;
                margin: 2px;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
            }
            QTabBar::tab:selected {
                background-color: #4CAF50;
                border: 2px solid #45a049;
            }
            QTabBar::tab:hover:!selected {
                background-color: #3d3d3d;
            }
        """)

        # Вкладка пользователей
        users_tab = QWidget()
        users_layout = QVBoxLayout(users_tab)
        
        # Таблица пользователей
        self.users_table = QTableWidget()
        self.users_table.setColumnCount(9)
        self.users_table.setHorizontalHeaderLabels([
            "ID", "Имя пользователя", "Пароль", "Баланс", "Админ", "VIP статус", "Всего выигрышей",
            "Всего проигрышей", "Дата регистрации"
        ])
        self.users_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.users_table.setStyleSheet("""
            QTableWidget {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
            }
            QHeaderView::section {
                background-color: #1d1d1d;
                color: white;
                padding: 5px;
                border: 1px solid #3d3d3d;
            }
            QTableWidget::item {
                padding: 5px;
            }
            QTableWidget::item:selected {
                background-color: #4CAF50;
            }
        """)
        users_layout.addWidget(self.users_table)

        # Кнопки управления пользователями
        user_buttons = QHBoxLayout()
        
        self.add_balance_btn = QPushButton("💰 Добавить баланс")
        self.add_balance_btn.clicked.connect(self.add_balance)
        user_buttons.addWidget(self.add_balance_btn)

        self.set_vip_btn = QPushButton("👑 Установить VIP")
        self.set_vip_btn.clicked.connect(self.set_vip)
        user_buttons.addWidget(self.set_vip_btn)

        self.delete_user_btn = QPushButton("❌ Удалить пользователя")
        self.delete_user_btn.clicked.connect(self.delete_user)
        user_buttons.addWidget(self.delete_user_btn)

        users_layout.addLayout(user_buttons)
        tabs.addTab(users_tab, "👥 Пользователи")

        # Вкладка статистики
        stats_tab = QWidget()
        stats_layout = QVBoxLayout(stats_tab)
        
        # Общая статистика
        total_stats = QWidget()
        total_stats_layout = QHBoxLayout(total_stats)
        
        # Получаем статистику
        total_users = self.session.query(User).count()
        total_games = self.session.query(GameHistory).count()
        total_wins = self.session.query(GameHistory).filter(GameHistory.win_amount > 0).count()
        total_losses = self.session.query(GameHistory).filter(GameHistory.win_amount == 0).count()
        
        stats_widgets = [
            (f"👥 Всего пользователей: {total_users}", "#4CAF50"),
            (f"🎮 Всего игр: {total_games}", "#2196F3"),
            (f"🏆 Побед: {total_wins}", "#FFC107"),
            (f"❌ Поражений: {total_losses}", "#F44336")
        ]
        
        for text, color in stats_widgets:
            stat_label = QLabel(text)
            stat_label.setStyleSheet(f"background-color: {color}; padding: 20px; border-radius: 10px;")
            stat_label.setFont(QFont('Arial', 14, QFont.Weight.Bold))
            total_stats_layout.addWidget(stat_label)
            
        stats_layout.addWidget(total_stats)
        
        # Таблица последних игр
        games_table = QTableWidget()
        games_table.setColumnCount(6)
        games_table.setHorizontalHeaderLabels(["Игрок", "Игра", "Ставка", "Выигрыш", "Результат", "Дата"])
        
        # Получаем последние 100 игр
        recent_games = self.session.query(GameHistory).order_by(GameHistory.played_at.desc()).limit(100).all()
        games_table.setRowCount(len(recent_games))
        
        for i, game in enumerate(recent_games):
            if game.user_id is not None:
                user = self.session.query(User).get(game.user_id)
            else:
                user = None
            games_table.setItem(i, 0, QTableWidgetItem(user.username if user else "Удалённый пользователь"))
            games_table.setItem(i, 1, QTableWidgetItem(game.game_type))
            games_table.setItem(i, 2, QTableWidgetItem(f"{game.bet_amount:.2f}"))
            games_table.setItem(i, 3, QTableWidgetItem(f"{game.win_amount:.2f}"))
            games_table.setItem(i, 4, QTableWidgetItem(game.result))
            games_table.setItem(i, 5, QTableWidgetItem(game.played_at.strftime("%Y-%m-%d %H:%M")))
            
        games_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        stats_layout.addWidget(games_table)
        
        tabs.addTab(stats_tab, "📊 Статистика")

        # Вкладка транзакций
        transactions_tab = QWidget()
        transactions_layout = QVBoxLayout(transactions_tab)
        
        # Таблица транзакций
        self.transactions_table = QTableWidget()
        self.transactions_table.setColumnCount(5)
        self.transactions_table.setHorizontalHeaderLabels([
            "ID", "Пользователь", "Сумма", "Тип", "Дата"
        ])
        self.transactions_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.transactions_table.setStyleSheet("""
            QTableWidget {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
            }
            QHeaderView::section {
                background-color: #1d1d1d;
                color: white;
                padding: 5px;
                border: 1px solid #3d3d3d;
            }
            QTableWidget::item {
                padding: 5px;
            }
            QTableWidget::item:selected {
                background-color: #4CAF50;
            }
        """)
        transactions_layout.addWidget(self.transactions_table)
        tabs.addTab(transactions_tab, "💰 Транзакции")

        # Вкладка управления вероятностями
        prob_tab = QWidget()
        prob_layout = QVBoxLayout(prob_tab)
        
        # Выбор пользователя
        user_selector = QComboBox()
        user_selector.addItem("Все пользователи", None)
        for user in self.session.query(User).all():
            user_selector.addItem(f"{user.username} (ID: {user.id})", user.id)
        prob_layout.addWidget(user_selector)
        
        # Таблица вероятностей
        prob_table = QTableWidget()
        prob_table.setColumnCount(3)
        prob_table.setHorizontalHeaderLabels(["Параметр", "Текущее значение", "Новое значение"])
        
        probability_params = [
            ("Общий шанс победы", "win_chance", 0, 100),
            ("Шанс джекпота (слоты)", "jackpot_chance", 0, 100),
            ("Шанс роял-флеша (покер)", "royal_chance", 0, 100),
            ("Шанс блэкджека", "blackjack_chance", 0, 100),
            ("Шанс красного (рулетка)", "red_chance", 0, 100),
            ("Шанс черного (рулетка)", "black_chance", 0, 100),
            ("Шанс зеро (рулетка)", "zero_chance", 0, 100),
            ("Шанс алмаза (скретч)", "diamond_chance", 0, 100)
        ]
        
        prob_table.setRowCount(len(probability_params))
        self.prob_spinboxes = {}
        
        def update_probabilities(user_id):
            if user_id:
                probs = self.session.query(GameProbability).filter_by(user_id=user_id).first()
            else:
                probs = self.session.query(GameProbability).filter_by(user_id=None).first()
                
            if not probs:
                probs = GameProbability(user_id=user_id)
                self.session.add(probs)
                self.session.commit()
                
            for i, (name, attr, min_val, max_val) in enumerate(probability_params):
                current_value = getattr(probs, attr)
                prob_table.setItem(i, 1, QTableWidgetItem(f"{current_value:.1f}"))
                self.prob_spinboxes[attr].setValue(current_value)
        
        for i, (name, attr, min_val, max_val) in enumerate(probability_params):
            prob_table.setItem(i, 0, QTableWidgetItem(name))
            prob_table.setItem(i, 1, QTableWidgetItem("0.0"))
            
            spinbox = QDoubleSpinBox()
            spinbox.setRange(min_val, max_val)
            spinbox.setDecimals(1)
            spinbox.setSingleStep(0.1)
            self.prob_spinboxes[attr] = spinbox
            prob_table.setCellWidget(i, 2, spinbox)
            
        prob_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        prob_layout.addWidget(prob_table)
        
        # Кнопка сохранения
        save_button = QPushButton("💾 Сохранить вероятности")
        def save_probabilities():
            user_id = user_selector.currentData()
            
            # Получаем или создаем записи для каждого типа игры
            game_types = ['slots', 'poker', 'blackjack', 'roulette', 'scratch']
            for game_type in game_types:
                probs = self.session.query(GameProbability).filter_by(
                    user_id=user_id,
                    game_type=game_type
                ).first()
                
                if not probs:
                    probs = GameProbability(user_id=user_id, game_type=game_type)
                    self.session.add(probs)
                
                # Устанавливаем общие вероятности
                if 'win_chance' in self.prob_spinboxes:
                    probs.win_chance = self.prob_spinboxes['win_chance'].value()
                
                # Устанавливаем специфичные вероятности в зависимости от типа игры
                if game_type == 'slots' and 'jackpot_chance' in self.prob_spinboxes:
                    probs.jackpot_chance = self.prob_spinboxes['jackpot_chance'].value()
                elif game_type == 'poker' and 'royal_chance' in self.prob_spinboxes:
                    probs.royal_chance = self.prob_spinboxes['royal_chance'].value()
                elif game_type == 'blackjack' and 'blackjack_chance' in self.prob_spinboxes:
                    probs.blackjack_chance = self.prob_spinboxes['blackjack_chance'].value()
                elif game_type == 'roulette':
                    if 'red_chance' in self.prob_spinboxes:
                        probs.red_chance = self.prob_spinboxes['red_chance'].value()
                    if 'black_chance' in self.prob_spinboxes:
                        probs.black_chance = self.prob_spinboxes['black_chance'].value()
                    if 'zero_chance' in self.prob_spinboxes:
                        probs.zero_chance = self.prob_spinboxes['zero_chance'].value()
                elif game_type == 'scratch' and 'diamond_chance' in self.prob_spinboxes:
                    probs.diamond_chance = self.prob_spinboxes['diamond_chance'].value()
            
            self.session.commit()
            QMessageBox.information(self, "Успех", "Вероятности успешно обновлены!")
            
            # Обновляем отображение текущих значений для всех игр
            update_probabilities(user_id)
            
        save_button.clicked.connect(save_probabilities)
        prob_layout.addWidget(save_button)
        
        user_selector.currentIndexChanged.connect(
            lambda: update_probabilities(user_selector.currentData())
        )
        update_probabilities(None)  # Загружаем начальные значения
        
        tabs.addTab(prob_tab, "🎲 Вероятности")

        # Вкладка запросов на пополнение
        deposits_tab = QWidget()
        deposits_layout = QVBoxLayout(deposits_tab)
        
        # Таблица запросов
        self.deposits_table = QTableWidget()
        self.deposits_table.setColumnCount(5)
        self.deposits_table.setHorizontalHeaderLabels(["Игрок", "Сумма", "Статус", "Дата", "Действия"])
        
        # Получаем все запросы на пополнение
        deposit_requests = self.session.query(DepositRequest).order_by(DepositRequest.created_at.desc()).all()
        self.deposits_table.setRowCount(len(deposit_requests))
        
        for i, request in enumerate(deposit_requests):
            user = self.session.query(User).get(request.user_id)
            self.deposits_table.setItem(i, 0, QTableWidgetItem(user.username))
            self.deposits_table.setItem(i, 1, QTableWidgetItem(f"{request.amount:.2f}"))
            self.deposits_table.setItem(i, 2, QTableWidgetItem(request.status))
            self.deposits_table.setItem(i, 3, QTableWidgetItem(request.created_at.strftime("%Y-%m-%d %H:%M")))
            
            if request.status == 'pending':
                actions_widget = QWidget()
                actions_layout = QHBoxLayout(actions_widget)
                
                approve_btn = QPushButton("✅")
                reject_btn = QPushButton("❌")
                
                def make_handler(req_id, approve):
                    return lambda: self.handle_deposit_request(req_id, approve)
                    
                approve_btn.clicked.connect(make_handler(request.id, True))
                reject_btn.clicked.connect(make_handler(request.id, False))
                
                actions_layout.addWidget(approve_btn)
                actions_layout.addWidget(reject_btn)
                self.deposits_table.setCellWidget(i, 4, actions_widget)
                
        self.deposits_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        deposits_layout.addWidget(self.deposits_table)
        
        # Вкладка магазина
        shop_tab = QWidget()
        shop_layout = QVBoxLayout(shop_tab)
        
        # Таблица товаров
        self.shop_table = QTableWidget()
        self.shop_table.setColumnCount(6)
        self.shop_table.setHorizontalHeaderLabels([
            "ID", "Название", "Описание", "Цена", "Тип", "Дата добавления"
        ])
        self.shop_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        
        # Получаем все товары
        shop_items = self.session.query(ShopItem).order_by(ShopItem.created_at.desc()).all()
        self.shop_table.setRowCount(len(shop_items))
        
        for i, item in enumerate(shop_items):
            self.shop_table.setItem(i, 0, QTableWidgetItem(str(item.id)))
            self.shop_table.setItem(i, 1, QTableWidgetItem(item.name))
            self.shop_table.setItem(i, 2, QTableWidgetItem(item.description))
            self.shop_table.setItem(i, 3, QTableWidgetItem(f"{item.price:.2f}"))
            self.shop_table.setItem(i, 4, QTableWidgetItem(item.type))
            self.shop_table.setItem(i, 5, QTableWidgetItem(item.created_at.strftime("%Y-%m-%d %H:%M")))
        
        shop_layout.addWidget(self.shop_table)
        
        # Кнопки управления магазином
        shop_buttons = QHBoxLayout()
        
        add_item_btn = QPushButton("➕ Добавить товар")
        add_item_btn.clicked.connect(self.add_shop_item)
        shop_buttons.addWidget(add_item_btn)
        
        edit_item_btn = QPushButton("✏️ Изменить товар")
        edit_item_btn.clicked.connect(self.edit_shop_item)
        shop_buttons.addWidget(edit_item_btn)
        
        delete_item_btn = QPushButton("❌ Удалить товар")
        delete_item_btn.clicked.connect(self.delete_shop_item)
        shop_buttons.addWidget(delete_item_btn)
        
        shop_layout.addLayout(shop_buttons)
        tabs.addTab(shop_tab, "🛍️ Магазин")

        layout.addWidget(tabs)

    def refresh_data(self):
        # Обновляем таблицу пользователей
        users = self.session.query(User).all()
        self.users_table.setRowCount(len(users))
        for i, user in enumerate(users):
            self.users_table.setItem(i, 0, QTableWidgetItem(str(user.id)))
            self.users_table.setItem(i, 1, QTableWidgetItem(user.username))
            self.users_table.setItem(i, 2, QTableWidgetItem(user.password))
            self.users_table.setItem(i, 3, QTableWidgetItem(f"{user.balance:.2f}"))
            self.users_table.setItem(i, 4, QTableWidgetItem("Да" if user.is_admin else "Нет"))
            self.users_table.setItem(i, 5, QTableWidgetItem("✅" if user.vip_status else "❌"))
            self.users_table.setItem(i, 6, QTableWidgetItem(f"{user.total_wins:.2f}"))
            self.users_table.setItem(i, 7, QTableWidgetItem(f"{user.total_losses:.2f}"))
            self.users_table.setItem(i, 8, QTableWidgetItem(user.created_at.strftime("%Y-%m-%d %H:%M")))

        # Обновляем таблицу транзакций
        transactions = self.session.query(Transaction).order_by(Transaction.created_at.desc()).all()
        self.transactions_table.setRowCount(len(transactions))
        for i, trans in enumerate(transactions):
            if trans.user_id is not None:
                user = self.session.query(User).get(trans.user_id)
            else:
                user = None
            self.transactions_table.setItem(i, 0, QTableWidgetItem(str(trans.id)))
            self.transactions_table.setItem(i, 1, QTableWidgetItem(user.username if user else "Удалённый пользователь"))
            self.transactions_table.setItem(i, 2, QTableWidgetItem(f"{trans.amount:.2f}"))
            self.transactions_table.setItem(i, 3, QTableWidgetItem(trans.type))
            self.transactions_table.setItem(i, 4, QTableWidgetItem(trans.created_at.strftime("%Y-%m-%d %H:%M")))

        # Обновляем таблицу магазина
        shop_items = self.session.query(ShopItem).order_by(ShopItem.created_at.desc()).all()
        self.shop_table.setRowCount(len(shop_items))
        for i, item in enumerate(shop_items):
            self.shop_table.setItem(i, 0, QTableWidgetItem(str(item.id)))
            self.shop_table.setItem(i, 1, QTableWidgetItem(item.name))
            self.shop_table.setItem(i, 2, QTableWidgetItem(item.description))
            self.shop_table.setItem(i, 3, QTableWidgetItem(f"{item.price:.2f}"))
            self.shop_table.setItem(i, 4, QTableWidgetItem(item.type))
            self.shop_table.setItem(i, 5, QTableWidgetItem(item.created_at.strftime("%Y-%m-%d %H:%M")))

    def add_balance(self):
        selected_items = self.users_table.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "Ошибка", "Выберите пользователя!")
            return

        row = selected_items[0].row()
        user_id = int(self.users_table.item(row, 0).text())
        user = self.session.query(User).get(user_id)

        amount, ok = QInputDialog.getDouble(
            self, "Добавить баланс",
            f"Введите сумму для пользователя {user.username}:",
            value=100.0, min=0.0, max=1000000.0
        )

        if ok:
            user.balance += amount
            
            # Создаем транзакцию
            transaction = Transaction(
                user_id=user.id,
                amount=amount,
                type='admin',
                description='Пополнение баланса администратором'
            )
            self.session.add(transaction)
            self.session.commit()
            self.refresh_data()

    def set_vip(self):
        selected_items = self.users_table.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "Ошибка", "Выберите пользователя!")
            return

        row = selected_items[0].row()
        user_id = int(self.users_table.item(row, 0).text())
        user = self.session.query(User).get(user_id)

        user.vip_status = not user.vip_status
        self.session.commit()
        self.refresh_data()

    def delete_user(self):
        selected_items = self.users_table.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "Ошибка", "Выберите пользователя!")
            return

        row = selected_items[0].row()
        user_id = int(self.users_table.item(row, 0).text())
        user = self.session.query(User).get(user_id)

        if user.is_admin:
            QMessageBox.warning(self, "Ошибка", "Нельзя удалить администратора!")
            return

        reply = QMessageBox.question(
            self, "Подтверждение",
            f"Вы уверены, что хотите удалить пользователя {user.username}?",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self.session.delete(user)
            self.session.commit()
            self.refresh_data()

    def handle_deposit_request(self, request_id, approve):
        request = self.session.query(DepositRequest).get(request_id)
        if not request:
            return
            
        user = self.session.query(User).get(request.user_id)
        if approve:
            user.balance += request.amount
            request.status = 'approved'
            message = f"Запрос на пополнение от {user.username} на сумму {request.amount:.2f} одобрен!"
        else:
            request.status = 'rejected'
            message = f"Запрос на пополнение от {user.username} на сумму {request.amount:.2f} отклонен!"
            
        request.processed_at = datetime.now()
        self.session.commit()
        QMessageBox.information(self, "Обработка запроса", message)
        self.setup_ui()  # Обновляем интерфейс

    def add_shop_item(self):
        # Получаем название предмета
        name, ok = QInputDialog.getText(
            self,
            "Добавить предмет",
            "Введите название предмета:"
        )
        if not ok or not name:
            return
            
        # Получаем цену предмета
        price, ok = QInputDialog.getDouble(
            self,
            "Добавить предмет",
            "Введите цену предмета:",
            value=100.0,
            minValue=0.0,
            maxValue=1000000.0,
            decimals=2
        )
        if not ok:
            return
            
        description, ok = QInputDialog.getText(self, "Добавить товар", "Описание:")
        if not ok or not description:
            return
            
        type_dialog = QInputDialog(self)
        type_dialog.setComboBoxItems(["booster", "cosmetic", "bundle", "feature"])
        type_dialog.setWindowTitle("Добавить товар")
        type_dialog.setLabelText("Тип товара:")
        if type_dialog.exec_() != QInputDialog.Accepted:
            return
        item_type = type_dialog.textValue()
        
        # Создаем новый товар
        item = ShopItem(
            name=name,
            description=description,
            price=price,
            type=item_type
        )
        self.session.add(item)
        self.session.commit()
        self.refresh_data()
        
    def edit_shop_item(self):
        selected_items = self.shop_table.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "Ошибка", "Выберите товар!")
            return
            
        row = selected_items[0].row()
        item_id = int(self.shop_table.item(row, 0).text())
        item = self.session.query(ShopItem).get(item_id)
        
        name, ok = QInputDialog.getText(
            self, "Изменить товар", "Название:",
            text=item.name
        )
        if not ok:
            return
            
        description, ok = QInputDialog.getText(
            self, "Изменить товар", "Описание:",
            text=item.description
        )
        if not ok:
            return
            
        price, ok = QInputDialog.getDouble(
            self, "Изменить товар", "Цена:",
            value=item.price, min=0.0, max=1000000.0
        )
        if not ok:
            return
            
        type_dialog = QInputDialog(self)
        type_dialog.setComboBoxItems(["booster", "cosmetic", "bundle", "feature"])
        type_dialog.setWindowTitle("Изменить товар")
        type_dialog.setLabelText("Тип товара:")
        type_dialog.setTextValue(item.type)
        if type_dialog.exec_() != QInputDialog.Accepted:
            return
        item_type = type_dialog.textValue()
        
        # Обновляем товар
        item.name = name
        item.description = description
        item.price = price
        item.type = item_type
        self.session.commit()
        self.refresh_data()
        
    def delete_shop_item(self):
        selected_items = self.shop_table.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "Ошибка", "Выберите товар!")
            return
            
        row = selected_items[0].row()
        item_id = int(self.shop_table.item(row, 0).text())
        item = self.session.query(ShopItem).get(item_id)
        
        reply = QMessageBox.question(
            self, "Подтверждение",
            f"Вы уверены, что хотите удалить товар {item.name}?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            self.session.delete(item)
            self.session.commit()
            self.refresh_data()

    def closeEvent(self, event):
        self.session.close()
        super().closeEvent(event) 