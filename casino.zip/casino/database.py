from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Enum
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import enum

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    
    # VIP преимущества
    VIP_WIN_MULTIPLIER = 1.5  # Множитель выигрыша для VIP
    VIP_INITIAL_BALANCE = 5000.0  # Начальный баланс для VIP
    VIP_DEPOSIT_BONUS = 0.1  # 10% бонус при пополнении
    VIP_MAX_BET_MULTIPLIER = 2.0  # Множитель для максимальной ставки
    
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    password = Column(String(100), nullable=False)
    balance = Column(Float, default=1000.0)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.now)
    last_login = Column(DateTime, default=datetime.utcnow)
    vip_status = Column(Boolean, default=False)
    vip_until = Column(DateTime, nullable=True)  # Для временного VIP статуса
    nickname_color = Column(String, nullable=True)  # Цвет никнейма
    badge = Column(String, nullable=True)  # Значок рядом с именем
    total_wins = Column(Float, default=0.0)
    total_losses = Column(Float, default=0.0)
    
    # Отношения
    game_history = relationship("GameHistory", back_populates="user")
    transactions = relationship("Transaction", back_populates="user")
    probabilities = relationship("GameProbability", back_populates="user")
    deposit_requests = relationship("DepositRequest", back_populates="user", cascade="all, delete-orphan")
    boosters = relationship("UserBooster", back_populates="user")
    daily_bonuses = relationship("DailyBonus", back_populates="user")
    achievements = relationship("Achievement", back_populates="user", cascade="all, delete-orphan")

    def check_password(self, password):
        return self.password == password  # В реальном приложении здесь должно быть хеширование

class GameHistory(Base):
    __tablename__ = 'game_history'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    game_type = Column(String, nullable=False)
    bet_amount = Column(Float, nullable=False)
    win_amount = Column(Float, nullable=False)
    result = Column(String, nullable=False)
    played_at = Column(DateTime, default=datetime.now)
    created_at = Column(DateTime, default=datetime.now)
    
    # Отношения
    user = relationship("User", back_populates="game_history")

class Transaction(Base):
    __tablename__ = 'transactions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    amount = Column(Float, nullable=False)
    type = Column(String, nullable=False)  # deposit, withdrawal, win, loss, bonus
    description = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    
    # Отношения
    user = relationship("User", back_populates="transactions")

class DailyBonus(Base):
    __tablename__ = 'daily_bonuses'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    amount = Column(Float, nullable=False)
    streak = Column(Integer, default=1)
    last_claimed = Column(DateTime, default=datetime.now)
    consecutive_days = Column(Integer, default=0)
    bonus_multiplier = Column(Float, default=1.0)
    hourly_bonus_enabled = Column(Boolean, default=False)
    last_hourly_bonus = Column(DateTime, nullable=True)
    
    user = relationship("User", back_populates="daily_bonuses")

class Leaderboard(Base):
    __tablename__ = 'leaderboard'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    game_type = Column(String, nullable=False)
    score = Column(Float, nullable=False)
    date = Column(DateTime, default=datetime.now)

class GameProbability(Base):
    __tablename__ = 'game_probabilities'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    game_type = Column(String)
    
    # Общие вероятности
    win_chance = Column(Float, default=50.0)
    
    # Специфичные вероятности для разных игр
    jackpot_chance = Column(Float, default=1.0)  # Для слотов
    royal_chance = Column(Float, default=0.1)    # Для покера
    blackjack_chance = Column(Float, default=5.0) # Для блэкджека
    red_chance = Column(Float, default=48.6)     # Для рулетки
    black_chance = Column(Float, default=48.6)   # Для рулетки
    zero_chance = Column(Float, default=2.8)     # Для рулетки
    diamond_chance = Column(Float, default=1.0)  # Для скретч-карт
    
    user = relationship("User", back_populates="probabilities")

class DepositRequest(Base):
    __tablename__ = 'deposit_requests'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    amount = Column(Float, nullable=False)
    status = Column(String, default='pending')  # pending, approved, rejected
    created_at = Column(DateTime, default=datetime.now)
    processed_at = Column(DateTime, nullable=True)
    
    # Отношения
    user = relationship("User", back_populates="deposit_requests")

class UserBooster(Base):
    __tablename__ = 'user_boosters'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    booster_type = Column(String, nullable=False)  # win_multiplier, loss_insurance, guaranteed_jackpot
    games_left = Column(Integer, nullable=False)  # Количество оставшихся игр
    created_at = Column(DateTime, default=datetime.now)
    expires_at = Column(DateTime, nullable=True)
    
    user = relationship("User", back_populates="boosters")

class ShopItem(Base):
    __tablename__ = 'shop_items'
    
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    description = Column(String, nullable=False)
    price = Column(Float, nullable=False)
    type = Column(String, nullable=False)  # booster, cosmetic, bundle, feature
    data = Column(String, nullable=True)  # JSON с дополнительными данными
    created_at = Column(DateTime, default=datetime.now)

class UserPurchase(Base):
    __tablename__ = 'user_purchases'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    item_id = Column(Integer, ForeignKey('shop_items.id'))
    purchase_date = Column(DateTime, default=datetime.now)
    expires_at = Column(DateTime, nullable=True)
    
    user = relationship("User")
    item = relationship("ShopItem")

class Achievement(Base):
    __tablename__ = 'achievements'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    name = Column(String, nullable=False)
    description = Column(String, nullable=False)
    reward = Column(Float, default=0.0)
    unlocked_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    
    user = relationship("User", back_populates="achievements")

# Создаем подключение к базе данных
engine = create_engine('sqlite:///casino.db')
Base.metadata.create_all(engine)

# Создаем фабрику сессий
Session = sessionmaker(bind=engine) 