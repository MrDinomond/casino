import sys
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                           QPushButton, QLabel, QStackedWidget, QLineEdit,
                           QMessageBox, QHBoxLayout, QDialog)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from database import Session, User, Base, engine
from games import SlotsGame, RouletteGame, PokerGame, BlackjackGame, ScratchGame
from admin.admin import AdminPanel
from datetime import datetime, timedelta

class CasinoApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🎰 Казино")
        self.setFixedSize(800, 600)
        
        # Инициализация базы данных
        Base.metadata.create_all(engine)
        
        # Создаем сессию
        self.session = Session()
        self.current_user = None
        self.game_windows = []  # Список для хранения ссылок на окна игр
        
        # Создаем стек виджетов
        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)
        
        # Создаем страницы
        self.setup_login_page()
        self.setup_main_page()
        
        # Показываем страницу входа
        self.stacked_widget.setCurrentIndex(0)
        
        # Устанавливаем стили
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
            }
            QLabel {
                color: white;
                font-size: 16px;
            }
            QPushButton {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 10px;
                font-size: 16px;
                font-weight: 600;
                min-width: 250px;
                min-height: 45px;
            }
            QPushButton:hover {
                background-color: #3d3d3d;
            }
            QLineEdit {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 10px;
                font-size: 16px;
                min-width: 250px;
            }
        """)

    def setup_login_page(self):
        login_page = QWidget()
        layout = QVBoxLayout(login_page)
        layout.setSpacing(20)
        layout.setContentsMargins(40, 40, 40, 40)
        
        # Заголовок
        title = QLabel("🎰 Добро пожаловать в казино!")
        title.setAlignment(Qt.AlignCenter)
        title.setFont(QFont('Arial', 24, QFont.Weight.Bold))
        layout.addWidget(title)
        
        # Поля ввода
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Имя пользователя")
        layout.addWidget(self.username_input)
        
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Пароль")
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.password_input)
        
        # Кнопки
        login_btn = QPushButton("🔑 Войти")
        login_btn.clicked.connect(self.login)
        layout.addWidget(login_btn)
        
        register_btn = QPushButton("📝 Зарегистрироваться")
        register_btn.clicked.connect(self.register)
        layout.addWidget(register_btn)
        
        self.stacked_widget.addWidget(login_page)

    def setup_main_page(self):
        main_page = QWidget()
        layout = QVBoxLayout(main_page)
        layout.setSpacing(15)  # Уменьшим отступы между элементами
        layout.setContentsMargins(30, 30, 30, 30)  # Уменьшим отступы от краев
        
        # Информация о пользователе
        self.user_info = QLabel()
        self.user_info.setAlignment(Qt.AlignCenter)
        self.user_info.setFont(QFont('Arial', 16))  # Немного уменьшим шрифт
        layout.addWidget(self.user_info)
        
        # Кнопки игр
        games_layout = QVBoxLayout()
        games_layout.setSpacing(10)  # Уменьшим отступы между кнопками
        
        # Создаем кнопки с одинаковым шрифтом
        game_font = QFont('Arial', 16, QFont.Weight.Medium)
        
        slots_btn = QPushButton("🎰  Слоты")
        slots_btn.setFont(game_font)
        slots_btn.clicked.connect(lambda: self.open_game('slots'))
        games_layout.addWidget(slots_btn)
        
        roulette_btn = QPushButton("🎲  Рулетка")
        roulette_btn.setFont(game_font)
        roulette_btn.clicked.connect(lambda: self.open_game('roulette'))
        games_layout.addWidget(roulette_btn)
        
        poker_btn = QPushButton("🃏  Покер")
        poker_btn.setFont(game_font)
        poker_btn.clicked.connect(lambda: self.open_game('poker'))
        games_layout.addWidget(poker_btn)
        
        blackjack_btn = QPushButton("♠️  Блэкджек")
        blackjack_btn.setFont(game_font)
        blackjack_btn.clicked.connect(lambda: self.open_game('blackjack'))
        games_layout.addWidget(blackjack_btn)
        
        scratch_btn = QPushButton("🎫  Скретч-карта")
        scratch_btn.setFont(game_font)
        scratch_btn.clicked.connect(lambda: self.open_game('scratch'))
        games_layout.addWidget(scratch_btn)
        
        layout.addLayout(games_layout)
        
        # Кнопка магазина
        shop_btn = QPushButton("🛍️ Магазин")
        shop_btn.clicked.connect(self.open_shop)
        layout.addWidget(shop_btn)
        
        # Кнопка админ-панели
        self.admin_btn = QPushButton("👑 Админ-панель")
        self.admin_btn.clicked.connect(self.open_admin_panel)
        self.admin_btn.hide()
        layout.addWidget(self.admin_btn)
        
        # Кнопка выхода
        logout_btn = QPushButton("🚪 Выйти")
        logout_btn.clicked.connect(self.logout)
        layout.addWidget(logout_btn)
        
        self.stacked_widget.addWidget(main_page)

    def login(self):
        username = self.username_input.text()
        password = self.password_input.text()
        
        user = self.session.query(User).filter_by(username=username).first()
        
        if user and user.password == password:
            self.current_user = user
            self.update_user_info()
            self.stacked_widget.setCurrentIndex(1)
            
            # Показываем кнопку админ-панели, если пользователь админ
            self.admin_btn.setVisible(user.is_admin)
            
            # Очищаем поля ввода
            self.username_input.clear()
            self.password_input.clear()
        else:
            QMessageBox.warning(self, "Ошибка", "Неверное имя пользователя или пароль!")

    def register(self):
        username = self.username_input.text()
        password = self.password_input.text()
        
        if not username or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все поля!")
            return
            
        if self.session.query(User).filter_by(username=username).first():
            QMessageBox.warning(self, "Ошибка", "Пользователь с таким именем уже существует!")
            return
            
        new_user = User(
            username=username,
            password=password,
            balance=1000,  # Начальный баланс
            created_at=datetime.now()
        )
        
        self.session.add(new_user)
        self.session.commit()
        
        QMessageBox.information(self, "Успех", "Регистрация успешна! Теперь вы можете войти.")
        
        # Очищаем поля ввода
        self.username_input.clear()
        self.password_input.clear()

    def update_user_info(self):
        if self.current_user:
            self.session.refresh(self.current_user)
            admin_badge = "👑 ADMIN | " if self.current_user.is_admin else ""
            vip_badge = "🌟 VIP | " if hasattr(self.current_user, 'is_vip') and self.current_user.is_vip else ""
            self.user_info.setText(f"👤 {admin_badge}{vip_badge}{self.current_user.username} | 💰 Баланс: {self.current_user.balance:.2f}")

    def open_game(self, game_type):
        if not self.current_user:
            QMessageBox.warning(self, "Ошибка", "Сначала войдите в систему!")
            return
            
        # Обновляем данные пользователя перед открытием игры
        self.session.refresh(self.current_user)
        
        game_window = None
        if game_type == 'slots':
            game_window = SlotsGame(self.current_user)
        elif game_type == 'roulette':
            game_window = RouletteGame(self.current_user)
        elif game_type == 'poker':
            game_window = PokerGame(self.current_user)
        elif game_type == 'blackjack':
            game_window = BlackjackGame(self.current_user)
        elif game_type == 'scratch':
            game_window = ScratchGame(self.current_user)
            
        if game_window:
            game_window.setGeometry(self.geometry())  # Устанавливаем такую же геометрию как у главного окна
            game_window.show()
            self.game_windows.append(game_window)  # Сохраняем ссылку на окно

    def open_admin_panel(self):
        if not self.current_user or not self.current_user.is_admin:
            QMessageBox.warning(self, "Ошибка", "У вас нет прав администратора!")
            return
            
        admin_panel = AdminPanel(self.current_user)
        admin_panel.setFixedSize(800, 600)  # Устанавливаем такой же размер, как у главного окна
        admin_panel.show()
        self.game_windows.append(admin_panel)

    def logout(self):
        self.current_user = None
        self.stacked_widget.setCurrentIndex(0)
        
        # Закрываем все открытые окна игр
        for window in self.game_windows:
            window.close()
        self.game_windows.clear()

    def closeEvent(self, event):
        # Закрываем все открытые окна игр
        for window in self.game_windows:
            window.close()
            
        if self.session:
            self.session.close()
        super().closeEvent(event)

    def open_shop(self):
        if not self.current_user:
            QMessageBox.warning(self, "Ошибка", "Сначала войдите в систему!")
            return
            
        # Создаем диалоговое окно магазина
        shop_dialog = QDialog(self)
        shop_dialog.setWindowTitle("🛍️ Магазин")
        shop_dialog.setFixedSize(800, 600)  # Устанавливаем такой же размер, как у главного окна
        shop_dialog.setStyleSheet("""
            QDialog {
                background-color: #1a1a1a;
            }
            QLabel {
                color: white;
                font-size: 16px;
            }
            QPushButton {
                background-color: #2d2d2d;
                color: white;
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                padding: 15px;
                font-size: 16px;
                font-weight: bold;
                min-width: 200px;
            }
            QPushButton:hover {
                background-color: #3d3d3d;
            }
        """)
        
        layout = QVBoxLayout(shop_dialog)
        layout.setSpacing(20)
        layout.setContentsMargins(40, 40, 40, 40)
        
        # Заголовок
        title = QLabel("🛍️ Магазин")
        title.setAlignment(Qt.AlignCenter)
        title.setFont(QFont('Arial', 24, QFont.Weight.Bold))
        layout.addWidget(title)
        
        # VIP статус
        vip_btn = QPushButton("🌟 VIP статус навсегда - 5000💰")
        vip_btn.clicked.connect(lambda: self.buy_vip(shop_dialog))
        layout.addWidget(vip_btn)
        
        # Права администратора
        admin_btn = QPushButton("👑 Права администратора - 50000💰")
        admin_btn.clicked.connect(lambda: self.buy_admin(shop_dialog))
        layout.addWidget(admin_btn)
        
        # Кнопка закрытия
        close_btn = QPushButton("Закрыть")
        close_btn.clicked.connect(shop_dialog.close)
        layout.addWidget(close_btn)
        
        shop_dialog.exec()

    def buy_vip(self, dialog):
        if self.current_user.balance < 5000:
            QMessageBox.warning(self, "Ошибка", "Недостаточно средств!")
            return
            
        confirm = QMessageBox.question(
            self,
            "Подтверждение покупки",
            "Вы уверены, что хотите купить VIP статус за 5000💰?\n\n"
            "Преимущества VIP:\n"
            "• Особый значок 🌟\n"
            "• Увеличенные бонусы\n"
            "• Эксклюзивные функции",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if confirm == QMessageBox.Yes:
            self.current_user.balance -= 5000
            self.current_user.is_vip = True  # Устанавливаем VIP статус
            self.session.commit()
            
            self.update_user_info()
            
            QMessageBox.information(self, "Успех", "VIP статус активирован!")
            dialog.close()

    def buy_admin(self, dialog):
        if self.current_user.balance < 50000:
            QMessageBox.warning(self, "Ошибка", "Недостаточно средств!")
            return
            
        confirm = QMessageBox.question(
            self,
            "Подтверждение покупки",
            "Вы уверены, что хотите купить права администратора за 50000💰?\n\n"
            "Преимущества администратора:\n"
            "• Особый значок 👑\n"
            "• Доступ к админ-панели\n"
            "• Полный контроль над казино",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if confirm == QMessageBox.Yes:
            self.current_user.balance -= 50000
            self.current_user.is_admin = True
            self.session.commit()
            
            self.update_user_info()
            self.admin_btn.setVisible(True)
            
            QMessageBox.information(self, "Успех", "Поздравляем! Теперь вы администратор казино!")
            dialog.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = CasinoApp()
    window.show()
    sys.exit(app.exec()) 